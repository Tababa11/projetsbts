<?php
class Article_model extends CI_Model
{
        public function __construct(){
        	parent::__construct();
			$this->load->database();
        }
		
		public function allArticles(){
			$sql = 'SELECT * FROM Article';
			$query = $this->db->query($sql);
			return ($query ->result_array());
		}
		
		public function accueilArticles(){
			$sql = 'SELECT * FROM Article where validate="1" ORDER BY date DESC LIMIT 3';
			$query = $this->db->query($sql);
			return ($query ->result_array());
		}
		
		public function nombreActu(){
			$sql = 'SELECT * FROM Article where validate="1"';
			$query = $this->db->query($sql);
			return ($query ->num_rows());
		}
		public function selectActu($page){
			if($page == 1){
				$OFFSET = 0;
			}
			else{
				$OFFSET = 4*($page-1);
			}
			$sql = 'SELECT * FROM Article where validate="1" ORDER BY date DESC LIMIT 4 OFFSET '.$OFFSET;
			$query = $this->db->query($sql);
			return ($query ->result_array());
		}
		
		public function delete($id){
			$this->db->where('id_article', $id);
			return $this->db->delete('Article');
		}
		
		
		public function ajout($date, $titre, $description, $contenucourt , $miniature){
			$data = array(
			 'date' => $date,
			 'titre' => $titre,
			 'description' => $description,
			 'contenu' => $contenucourt,
			 'miniature' => $miniature
			);
			
			return( $this->db->insert('Article',$data));
		}
		public function idDernierArticle()
		{
			$sql= 'SELECT max(id_article) FROM Article';
			$query = $this->db->query($sql);
			return ($query->result_array()["0"]["max(id_article)"]);
		}
		
		public function selectById($id){
			$sql = 'SELECT * FROM Article where id_article='.$id;
			$query = $this->db->query($sql);
			return ($query ->result_array());
		}
		
		public function updateArticle($id, $data){
			$this->db->where('id_article', $id);
			return $this->db->update('Article', $data);
		}

}
?>