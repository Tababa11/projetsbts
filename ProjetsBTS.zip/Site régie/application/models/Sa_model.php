<?php
class Sa_model extends CI_Model{
	
    public function __construct(){
    	parent::__construct();
		$this->load->database();
    }
	
	public function verifSA($id)
	{
		$sql = "select * from users_groups where user_id='".$id."' and group_id=3 ";
		$query = $this->db->query($sql);
		return ($query ->result_array());
	}
	public function validateArticle($id)
	{
		$data = array(
			 'validate' => '1'
			);
		$this->db->where('id_article', $id);
		return	$this->db->update('Article', $data);
	}
	public function allChiffres()
	{
		$sql = "select * from chiffres";
		$query = $this->db->query($sql);
		return $query->result_array();
	}


}