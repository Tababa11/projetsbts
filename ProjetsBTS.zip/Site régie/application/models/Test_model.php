<?php
class Test_model extends CI_Model
{
        public function __construct()
        {
        	parent::__construct();
			$this->load->database();
        }
		
		public function test(){
			$sql = 'SELECT * FROM test';
			$query = $this->db->query($sql);
			return ($query ->result_array());
		}
}
?>