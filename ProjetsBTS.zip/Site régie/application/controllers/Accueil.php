<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accueil extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('article_model');		
		$this->load->view('templates/header.php');
		$this->load->view('templates/nav.php');
	}
	
	public function index(){
		$data['lesArticles'] = $this->article_model->accueilArticles();

		$this->load->view('Accueil.php', $data);
		$this->load->view('templates/footer.php');
	}
	
	public function proximite_LS(){
		$this->load->view('proximite-LS.php');
		$this->load->view('templates/footer.php');
	}
	
	public function ouNousRetrouver()
	{
		$this->load->view('ouNousRetrouver.php');
		$this->load->view('templates/footer.php');
	}
	
	public function notreFonctionnement()
	{
		$this->load->view('notreFonctionnement.php');
		$this->load->view('templates/footer.php');
	}
	
	public function nosMissions(){
		$this->load->view('mission.php');
		$this->load->view('templates/footer.php');
	}
	
	public function insertionSocialePro()
	{
		$this->load->view('insertionSocialePro.php');
		$this->load->view('templates/footer.php');
	}
	public function lieuPermanence()
	{
		$this->load->view('lieuPermanence.php');
		$this->load->view('templates/footer.php');
	}
	
	public function actualites($id=null){
			$data['unArticle'] = $this->article_model->selectById($id);
			
			$this->load->view('uneActu.php', $data);
			$this->load->view('templates/footer.php');

	}
	
	public function lesActus($page=null){
		if($page!=null){
			$data['lesArticles'] = $this->article_model->selectActu($page);
			$nombre = $this->article_model->nombreActu();
			
			$data['page'] = $page;
			$valeur = $nombre/4;
			if($nombre%4 == 0){
				$data['nbPages'] = $valeur;
			}
			else{
				$data['nbPages'] = ceil($valeur);
			}
			
			$this->load->view('actu.php', $data);
			$this->load->view('templates/footer.php');
		}
		else{
			show_404();
		}

	}
	
	public function cnlrq(){
		$this->load->view('cnlrq.php');
		$this->load->view('templates/footer.php');
	}
	
	public function notreHistoire(){
		$this->load->view('notreHistoire.php');
		$this->load->view('templates/footer.php');
	}
	
	public function partenaires(){
		$this->load->view('partenaires.php');
		$this->load->view('templates/footer.php');
	}
	

	public function boite_a_linge(){
		$this->load->view('boite-linge.php');
		$this->load->view('templates/footer.php');
	}
	
	public function mediation(){
		$this->load->view('mediation.php');
		$this->load->view('templates/footer.php');
	}
	
	public function aop(){
		$this->load->view('aop.php');
		$this->load->view('templates/footer.php');
	}

	public function join_us(){
		$this->load->view('Join-us.php');
		$this->load->view('templates/footer.php');
	}

	public function contact($data=null){
		
		$data['securite'] = rand(1000,9999);
		
		$this->load->view('Contact.php',$data);
		$this->load->view('templates/footer.php');
    }
	
	
	
	
	public function mail(){
		
        if(isset( $_POST['name']))
            $name = $_POST['name'];
        else
            show_404 ();
        if(isset( $_POST['email']))
            $email = $_POST['email'];
        else
            show_404 ();
        if(isset( $_POST['message']))
            $message = $_POST['message'];
        else
            show_404 ();
        if(isset( $_POST['subject']))
            $subject = $_POST['subject'];
        else
            show_404 ();
        
		if($_POST["secuHidden"] == $_POST['secu']){
			$content="Expéditeur: ".$name." \n Email: ".$email." \n \n ".$message;
        	$recipient = "secretariat@regiedesquartiers.com";
        	$mailheader = "De: $email \r\n";
       		if(imap_mail(imap_utf8($recipient), imap_utf8($subject), imap_utf8($content), imap_utf8($mailheader))){
       			$data["success"]="ok";
       		}
       		else{
       			$data["success"]="false";
       		} 	
		}
		else {
			$data["success"]="false";
		}
		$this->contact($data);
	}
	
	public function test(){
		$this->load->view('textbox.php',$data);
		$this->load->view('templates/footer.php');
	}
	

	
	
	
}

?>
