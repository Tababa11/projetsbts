<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sa extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->lang->load('auth');
		$this->load->library(array('ion_auth', 'form_validation'));
		$this->load->helper(array('url', 'language'));
		$this->load->model('article_model');
		$this->load->model('sa_model');
		
		if(!isset($_SESSION['user_id'])){
			show_404();
		}
		else{
			$groups = $this->sa_model->verifSA($_SESSION['user_id']);
			
			if(!$groups== null){
				$this->load->view('templates/headerSA.php');
				$this->load->view('templates/navSA.php');
			}
			elseif($this->ion_auth->is_admin()){
				redirect('Admin/allArticles');
			}
		}
	}
	public function appercuArticle($id)
	{
		if($id!=null){
			$data['unArticle'] = $this->article_model->selectById($id);
			$this->load->view('templates/header.php');
			$this->load->view('templates/navPreview.php');
			$this->load->view('uneActu.php', $data);
			$this->load->view('templates/footer.php');
		}
		else{
			show_404();	
		}
	}
	
	public function chiffresCles()
	{
		$data['stats'] = $this->sa_model->allChiffres();
		$this->load->view('SA/statistics.php', $data);
	}
	
	public function ecrireArticle($success=null){
		$data['success']=$success;
		$this->load->view('SA/newArticle.php', $data);
	}
	
	public function ajouterArticle(){
		if(isset($_FILES) && $_FILES['miniature']['type']!="")
		{
			
				/* -----------------------------  Upload image ----------------------------- */
			
			$config['upload_path']          = './uploads/';
	        $config['allowed_types']        = 'gif|jpg|png|jpeg|pneg';
	        $config['max_size']             = 20000;
	        $config['max_width']            = 5000;
	        $config['max_height']           = 5000;
	
	        $this->load->library('upload', $config);
			$_FILES['miniature']['name']= str_replace(" ","_", $_FILES['miniature']['name']);
	        if(! $this->upload->do_upload('miniature')){
	        	echo"PROBLEME";
	        }
	        else{
	            $data = array('upload_data' => $this->upload->data());	
				}
			$miniature=$_FILES['miniature']['name'];
		}
		else{
			$miniature="RDQ.png";
		}
		if($this->article_model->ajout( date('Y-m-d') ,$_POST['titre'], $_POST['description'] , $_POST['contenu'] , $miniature )){
			$success = 'yes';
		}
		else {
			$success = 'no';
		} 
			$this->ecrireArticle($success);
        
		
	}
	
	public function supprimerArticle($id){
		if($this->article_model->delete($id)){
			$success = 'OK';
		}
		else{
			$success = 'KO';
		}
		redirect('Sa/allArticles/'.$success);
	}
	
	public function modifierArticle($id){
		$data['article'] = $this->article_model->selectById($id);
		
		$this->load->view('SA/editArticle.php', $data);
	}
	
	public function updateArticle($id){
		/* -----------------------------  Upload image ----------------------------- */
		if(isset($_FILES) && $_FILES['miniature']['type']!="")
		{
			$config['upload_path']          = './uploads/';
	        $config['allowed_types']        = 'gif|jpg|png|jpeg|pneg';
	        $config['max_size']             = 20000;
	        $config['max_width']            = 5000;
	        $config['max_height']           = 5000;
	
	        $this->load->library('upload', $config);
			$_FILES['miniature']['name']= str_replace(" ","_", $_FILES['miniature']['name']);
	        if(! $this->upload->do_upload('miniature'))
	        {
	        	echo "PROBLEME" ;				
			}
			else
			{
				 $data = array('upload_data' => $this->upload->data());
			}
			$data = array(
			'titre' => $_POST['titre'],
			'description' => $_POST['petitedescription'],
			'contenu' => $_POST['description'],
			'miniature' => $_FILES['miniature']['name']);
        }
		else{
			$data = array(
			'titre' => $_POST['titre'],
			'description' => $_POST['petitedescription'],
			'contenu' => $_POST['description']);
		}	
		if($this->article_model->updateArticle($id, $data)){
		$this->allArticles("MOK");
        }	
	}
	
	public function allArticles($success=null){
		if(isset($success)){
			if($success == 'OK'){ $data['success'] = 'OK' ;}
			elseif($success == 'KO'){$data['success'] = 'KO' ;}
		}

		$data['lesArticles'] = $this->article_model->allArticles();
		
		$this->load->view('SA/allArticles.php', $data);
	}
	
	public function validate($id){
		
		if($this->sa_model->validateArticle($id)){
			$this->allArticles();
		}
	}

}
		