<script type="text/javascript">
	doActive("qsn")
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="text-center ecart"><strong>La Régie de Quartiers du Carcassonnais</strong></h2>
			<p class="">
				La Régie de Quartiers du Carcassonnais est née en novembre 1998, elle a ainsi fêté ses 20 ans en 2018. Elle est labélisée au Comité National 
				de Liaison des Régies de Quartier (CNLRQ) depuis 2011. Aux côtés des collectivités, des acteurs de terrain, des bailleurs sociaux 
				et des professionnels, la Régie propose un projet original entre <strong> insertion par l’activité économique, économie solidaire et éducation populaire</strong>, 
				le tout en associant largement les habitants.
				Son projet s'articule ainsi autour de 3 dimensions : 
				
			</p>
			<ul class="maList ecart">
				<li class="carreV ecartt">
					<span class=" "><strong>Une dimension sociale :</strong> générer du lien social à travers ses activités et ses services, créer des emplois destinés aux habitants les plus en difficulté du territoire, leur permettre de construire un véritable parcours d’insertion par un accompagnement socioprofessionnel et une formation adaptée. </span>
				</li>
				<li class="carreVert ecartt">
					<span class=" "><strong>Une dimension économique :</strong> exécuter des travaux pour les collectivités et les bailleurs dans le cadre de la gestion urbaine de proximité (entretien, maintenance et embellissement du cadre de vie), créer des activités pour répondre à des besoins collectifs non satisfaits ou émergents.</span>
				</li>
				<li class="carreO ecartt">
					<span class=""><strong>Une dimension politique :</strong> renforcer la participation des habitants à la vie associative et au développement de leur territoire, contribuer à faire émerger une citoyenneté active pour un « mieux vivre ensemble ».</span>
				</li>
			</ul>
			<p class="">
				Dans cette logique, au cours de ces 20 dernières années, les activités de l'association se sont diversifiées afin de s'adaper aux besoins des habitants, aux réalités du terrain ou encore aux finalités et enjeux des différents acteurs et politiques publiques. Aujourd'hui, nous portons une double mission  :
			</p>
		
			<ul class="maList ">
				<li class="carreR ecartt">
					<span class=""><strong>L'insertion</strong> grâce à plusieurs dispositifs adaptés aux besoins des habitants
				 	(1er accueil professionnel, Chantiers Tremplin, Ateliers et Chantiers d’Insertion, Entreprise d’insertion, 
					laverie solidaire : La Boîte à Linge). Des postes en contrats aidés sont également proposés.</span>
				</li>
				<img class="rounded mx-auto d-block" id="imageNotreHistoire" src="<?php echo base_url();?>images/imageNotreHistoire.png" />
				<p class="text-center text-muted"><small>Photo : Pierre-Emmanuel Weck</small></p>
		
				<li class="carreB ecartt">
					<span><strong>La Proximité, le lien social et la participation citoyenne</strong> en s’appuyant sur une équipe de médiateurs chargés de favoriser l’amélioration du cadre de vie, l’accès aux droits, la participation des habitants, le développement de la citoyenneté et des pratiques solidaires. Des éco médiateurs interviennent également dans la lutte contre la précarité énergétique.</span> 
				</li>
				<img class="rounded mx-auto d-block" id="equipeMediation" src="<?php echo base_url();?>images/equipeMediation.JPG" />
				<p class="text-center text-muted"><small>Préparation d'une action de sensibilisation par l'équipe de médiateurs</small></p>
			</ul>
		</div>
	</div>
</div>
