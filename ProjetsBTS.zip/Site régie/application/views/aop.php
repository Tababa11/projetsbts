<script type="text/javascript">
	doActive("sah")
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="text-center ecart "><strong>L'accueil Orientation Professionnelle</strong></h2>
			<p class="">La mission du service Accueil Orientation Professionelle est d'accueillir et d'orienter les habitants 
				vers les structures sociales et professionnelles les plus adaptées à leur projet.
			</p>
			<ul class="maList">
				<li class="ecartt carreVert"><span>Vous avez besoin de <strong>faire le point</strong> sur votre projet professionnel ?</span></li>
				<li class="ecartt carreV"><span>Vous vous demandez par où <strong>commencer</strong> ?</span></li>
				<li class="ecartt carreB"><span>Vous souhaitez organiser votre <strong>recherche d'emploi</strong> ?</span></li>
				<li class="ecartt carreR"><span>Vous cherchez à <strong>accéder</strong> à un emploi (lettre de motivation, CV) ?</span></li>
				<li class="ecartt carreO"><span>Vous voulez connaître les <strong>structures</strong> qui peuvent vous aider et vous accompagner ?</span></li>
			</ul>
			<p class="texte">Les conseillers en insertion professionnelle de la Régie des Quartiers peuvent vous guider :</p>
			<table class="table">
			  <thead>
			    <tr>
			      <th scope="col"><strong>Conseillers en insertion professionnelle</strong></th>
			      <th scope="col">06.84.27.25.04<br>07.87.87.75.48</th>
			    </tr>
			  </thead>
			</table>
		</div>
	</div>
</div>