<script type="text/javascript">
	doActive("sah")
</script>

<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="text-center  ecart"><strong>La Boîte à linge</strong></h2>
			<p class=""> 
				<strong>La Boîte à Linge est une laverie sociale et solidaire </strong>qui a ouvert ses portes en décembre 2013, elle est implantée au 
				cœur du centre commercial du Viguier, <a href="https://goo.gl/maps/MQeQrXbN3CL2" target="blank"><i class="fas fa-search"></i></a> rue Alain Fournier. Ses activités sont supports à une démarche d’insertion sociale 
				et professionnelle et au développement du lien social (rencontres des habitants, diffusion d'informations, ateliers et animations).
				Ce projet participe également au quotidien à redynamiser l'activité économique de proximité et à accroitre l'attractivité du 
				Viguier.
			</p>
			<img class="rounded mx-auto d-block ecart" src="<?php echo base_url();?>images/Boite.png" alt="Devanture"/>
			<p> <strong>Elle propose plusieurs services aux habitants mais également aux professionnels :</strong></p>
				<ul class="maList ">
					<li class="carreJ ecartt"><span><strong>Laverie automatique ou assistée</strong> : la Boîte à linge est équipée
						de matériel professionnel de grande capacité pour le lavage et le séchage du linge. Les clients ont
						la possibilité de laver et de sécher eux-mêmes leur linge ou de le confier au personnel de la laverie.
						</span></li>
					<li class="carreO ecartt"><span><strong>Repasserie :</strong> la Boîte à linge propose des prestations de repassage du 
						linge au kilo ou à l'unité. Nous sommes équipés d'une table à repasser professionnelle et d'une repasseuse à rouleaux.
						 Nous pouvons ainsi prendre en charge les pièces de grande taille telles que des draps.</span></li>
					<li class="carreVert ecartt"><span><strong>Entretien des tapis</strong> : nous sommes équipés d'injecteurs/extracteurs,
						d'aspirateurs et d'une shampouineuse à tapis.</span></li>
					<li class="carreB ecartt"><span><strong>Dépôt et vente de vêtements</strong> : vous pouvez déposer vos vêtements en bon état,
						nous nous chargeons de les vendre pour vous sur la base d'un partage des recettes.</span></li>
					<li class="carreV ecartt"><span><strong>Couture et retouche de vêtements</strong> : la Boîte à linge dispose des
						compétences et du matériel pour réaliser tous vos petits travaux de couture.</span></li>
					<li class="carreR ecartt"><span><strong>Enlèvement et livraison à domicile</strong> : ce service peut répondre à vos
						besoins spécifiques (personnes âgées ou peu mobiles, entretien du linge de collectivités, de professionnels,
						 d'associations...)</span></li>
				</ul>
			<div class="row">
			<img class="rounded mx-auto d-block " style="padding-bottom: 30px;"  src="<?php echo base_url();?>images/depotvente.jpeg" alt="Intérieur de la boite à linge">
			<img class="rounded mx-auto d-block " style="padding-bottom: 30px;"  src="<?php echo base_url();?>images/machine.jpeg" alt="Intérieur de la boite à linge">
			</div>
			<h5 class="mx-auto text-center ecart"><strong>En utilisant les différents services de la Boîte à linge, vous soutenez une démarche sociale et solidaire.</strong></h5>
			
			<p class=""><strong>Les équipes de la Boîte à Linge sont à votre entière disposition pour vous rencontrer et discuter avec vous
				de nos prestations.</strong> </p>
				<table class="table table-bordered">
				    <tr>
				      <td class="text-center" colspan="3">Horaires</td>
				    </tr>
				  <tbody>
				    <tr>
				      <td rowspan="2">Du Mardi au Samedi</td>
				      <td>Matin</td>
				      <td>Après-midi</td>
				    </tr>
				    <tr>
				    	<td>9h30 à 12h30</td>
				    	<td>14h à 18h</td>
				    </tr>
				  </tbody>
				</table>
				<!-- -->
			<!--<p class="">
				Cette action s'inscrit dans une véritable démarche partenariale puisque dans sa mise en œuvre, 
				elle associe des structures présentes sur le terrain autour de la mise en place de projets d’animation 
				et d’implication citoyenne (Centre social Jean Montsarrat, Les Petits Débrouillards, Conseil Citoyen…) 
				mais également les partenaires plus institutionnels tels que l'Etat, l'Agglomération du Carcassonnais ou 
				encore le Département de l’Aude et la ville de Carcassonne. Le bailleur social ALOGEA est également un 
				partenaire privilégié du projet. Les partenaires du Contrat de Ville, engagés dans ce projet depuis sa 
				genèse, continuent à nous accompagner car ils sont conscients que la Boîte à Linge est devenue un véritable 
				outil favorisant le développement économique et la participation citoyenne. Les acteurs de l’Insertion par 
				l’Activité Economique (DIRECCTE et Département principalement) attendent que nous continuions à proposer ce 
				dispositif d’insertion pour permettre la montée en compétences des habitants et donc favoriser leur insertion 
				professionnelle. Cet enjeu nous semble d’autant plus important que des débouchés réels en termes d’emplois 
				existent sur le territoire notamment dans les métiers de l’aide à la personne et de la blanchisserie.
			</p>-->
		</div>
	</div>
</div>