<body class="allArticles">
	<?php 
	if(isset($success)){
    	if( $success=="OK"){
    		echo "<p class='alert alert-success'>L'article a été supprimé.</p>";
    	}    
        else{
        	echo "<p class='alert alert-danger'>L'article n'a pas pu être supprimé.<p>";
        }        
    }
    ?>
<div class="container">
	<table class="table table-striped tabArticle">
	  <thead>
	    <tr>
	      <th scope="col">#</th>
	      <th scope="col">Titre</th>
	      <th scope="col">Date</th>
	      <th scope="col">Status</th>
	      <th scope="col">Actions</th>
	    </tr>
	  </thead>
	  <tbody>
	  	<?php 
	  	
	  		foreach($lesArticles as $unArticle){
				$date = explode('-',$unArticle['date']);
				$date = $date['2'].'-'.$date['1'].'-'.$date['0'];
				
	  			echo '<tr>';
				echo '<th scope="row">'.$unArticle['id_article'].'</th>';
				echo '<td>'.$unArticle['titre'].'</td>';
				echo '<td>'.$date.'</td>';
				echo '<td>';
				if($unArticle['validate']){
					echo "VALIDÉ";
				}
				else {
					echo 'En attente';
				}
				echo'</td>';
				echo '<td>';
				echo anchor('Admin/modifierArticle/'.$unArticle['id_article'], '<i class="fas fa-edit icones"></i>');
				echo anchor('Admin/appercuArticle/'.$unArticle['id_article'], '<i class="fas fa-search"></i>');
				echo '</td>';
				echo '</tr>';
	  		}
	  		
	  	?>
	
	  </tbody>
	</table>
</div>
</body>