<body class="allArticles">
	<div class="container">
		<div class="row">
			<div class="bodyWhite col-md-12">
	<?php 
if(isset($success)){
    	if( $success=="yes"){
    		echo "<p class='alert alert-success'>L'article a été publié.</p>";
    	}    
        else{
        	echo "<p class='alert alert-danger'>L'article n'a pas pu être publié.<p>";
        }        
    }


$this->load->helper('form');
echo form_open_multipart('Admin/updateArticle/'.$article["0"]["id_article"].'');
echo form_fieldset('Nouvelle Actualité');
echo form_label("Titre de l'article");
$data= array(
'name' => 'titre',
'type' => 'text',
'value' => $article["0"]["titre"],
'style' => 'width:750px',
'class' => 'form-control form-control-lg'
);

echo form_input($data);

echo'<br><br>';
echo'<h3>Inserez l\'image qui servira de miniature</h3>';
echo'<input type="file" name="miniature" />';
echo '<img id="imgActu" class="imgPreview col-md-4" src="'.base_url().'uploads/'.$article["0"]["miniature"].'" alt="logo"/>';
echo'<br><br>';
echo form_label("Courte description de l'article");
echo '<textarea type="text" id="petitedescription" name="petitedescription" rows="2"  class="form-control md-textarea">'.$article["0"]["description"].'</textarea>';
 
echo'<br><br>';

echo form_label("Contenu de l'article");
echo '<textarea type="text" id="description" name="description" rows="10" style="line-height:1.0" class="form-control md-textarea">'.$article["0"]["contenu"].'</textarea>';
$data = array(
 'type' => 'submit',
 'value' => 'envoyer'
 );
 
echo form_input($data);
echo form_fieldset_close();
echo form_close();

?>

		</div>
	</div>
</div>

<script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">

bkLib.onDomLoaded(
	function() 
		{	/* utiliser nicEdit complet sur la textarea description */
			new nicEditor().panelInstance('description');
			/* utiliser nicEdit court sur la textarea petitedescription */
			new nicEditor({buttonList : ['fontSize','fontFamily','fontFormat','bold','italic','underline','strikeThrough','subscript','superscript','html']}).panelInstance('petitedescription');

		});
		
		
</script>

</body>
<script type="text/javascript">	

	</script>
