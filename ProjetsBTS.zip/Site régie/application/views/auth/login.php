<!DOCTYPE html>
<html>
	<head>
			
		<title>SE CONNECTER</title>
		<meta charset="utf-8">	
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="stylesheet" type="text/css" href="<? echo base_url();?>/css/style.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">        
		<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css%22%3E">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css%22%3E">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/css/mdb.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" >
		
	</head>
	<body>		
				
		
<div class="container">
	<div class="row">
		<div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
			<div class="card card-signin my-5">
				<div class="card-body">
					<h1 class="card-title text-center"><?php echo lang('login_heading');?></h1>
						
					<p>Veuillez vous connecter avec adresse mail et votre mot de passe. </p>
					<div id="infoMessage"><?php echo $message;?></div>
					<?php echo form_open("auth/login");?>
						<div class="form-label-group">
							<?php echo form_label('Adresse mail', 'identity','identity');?>
							<?php echo form_input($identity);?>
						</div>
						<div class="form-label-group">
							<?php echo form_label(lang('login_password_label', 'password'),'password');?>
							<?php echo form_input($password);?>
						</div>

						<div class="custom-control custom-checkbox mb-3">
							<?php echo form_label(lang('login_remember_label', 'remember'));?>
							<?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
						</div>
						<?php echo form_submit('submit', lang('login_submit_btn'),'class="btn btn-lg btn-primary btn-block text-uppercase"');?>

					<?php echo form_close();?>

					<p><a href="forgot_password"><?php echo lang('login_forgot_password');?></a></p>
    
				</div>
			</div>
		</div>
	</div>
</div>	
	</body>
</html>