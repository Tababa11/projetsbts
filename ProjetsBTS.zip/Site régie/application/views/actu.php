<script type="text/javascript">
	doActive("actu")
</script>
<div>
	
</div>


<?php 	
echo '<div class="container uneActu">';	
	echo '<div class="card-deck">';
	foreach($lesArticles as $unArticle)
	{
		echo '<div class="card">';
		if($unArticle['validate'])
		{
		$date = explode('-',$unArticle['date']);
		$date = $date['2'].'-'.$date['1'].'-'.$date['0'];
		
			echo '<img id="imgActu" src="'.base_url().'uploads/'.$unArticle['miniature'].'" class="card-img-top" alt="logo"/>';
			echo '<div class="card-body">';
			  echo '<h5 class="card-title"><a href="'.base_url().'index.php/Accueil/actualites/'.$unArticle['id_article'].'" class="">'.$unArticle['titre'].'</a></h5>';
			  echo '<p class="card-text">'.$unArticle['description'].'</p>';
			echo '</div>';
			echo '<div class="card-footer">';
			  echo '<small class="text-muted">'.$date.'</small>';
			  echo '<a id="btnPlus" class="btn btn-dark btn-circle btn-animate" href="'.base_url().'index.php/Accueil/actualites/'.$unArticle['id_article'].'">';
				echo '<span class="blanc">EN SAVOIR PLUS</span>';
			echo '</a>';
			echo '</div>';
		
		}
		echo '</div>';
	}
	echo '</div>';
echo '</div>';
?>

<div class="container">
	<div class="row col-md-8 mx-auto">
	</div>
</div>

<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
  	
  	<?php
		if($page == 1){$pagePrec = $page; }
		else{ $pagePrec = $page-1 ; }
		
		if($page == $nbPages){ $pageSuiv = $page; }
		else{ $pageSuiv = $page+1; }
		
		if($page > $nbPages){ show_404(); }
		
		if($page >= 4 ){
			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$pagePrec.'">Précedent</a></li>';
			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/1">Début</a></li>';
			/*for($i = ($page-2) ; $i <= ($page+2) ; $i++){
				echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$i.'">'.$i.'</a></li>';
			}*/
			$i = $page-2;
			while($i <= $nbPages && $i <= $page+2){
				echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$i.'">'.$i.'</a></li>';
				$i = $i +1 ;
			}
			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$nbPages.'">Fin</a></li>';
			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$pageSuiv.'">Suivant</a></li>';
		}
		else{
			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$pagePrec.'">Précedent</a></li>';
			for($i=1 ; $i<=$nbPages; $i++){
   				echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$i.'">'.$i.'</a></li>';
   			}
   			echo '<li class="page-item"><a class="page-link" href="'.base_url().'index.php/Accueil/lesActus/'.$pageSuiv.'">Suivant</a></li>'; }
	?>
  </ul>
</nav>
    	