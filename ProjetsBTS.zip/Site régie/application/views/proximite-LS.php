<script type="text/javascript">
	doActive("missions")
</script>
<div class="container page">
	<div class="row">
		<div class="col-md-10 text-justify mx-auto">
			<h2 class="ecart text-center "><strong>Proximité, lien social et participation citoyenne</strong></h2>
			<p class="">
				Les prestations techniques proposées par la Régie, qu'il s'agisse de maintenir, d'entretenir ou d'embellir le territoire,
				se traduisent par une activité économique favorisant l'insertion sociale et professionnelle des habitants, mais ces
				prestations sont également le support d'<strong>une démarche de médiation et de sensibilisation</strong>. Elle repose sur l'intervention
				de professionnels aux compétences spécifiques :
			</p>
			<ul class="maList">
				<li class="carreB ecartt">
					<span><strong>Des médiateurs chargés principalement de favoriser l’amélioration du cadre de vie</strong> (veille technique,
						actions de sensibilisation, rappels des règles d'utilisation des espaces communs ou privés, dissuasion des dégradations...) mais
						chargés également de faciliter l’accès aux droits (soutien administratif, interface avec des organismes divers
						tels que la CAF, la CPAM ou encore les caisses de retraite...) et d'intervenir dans les cas de conflits de voisinage.
						 Les médiateurs travaillent en partenariat étroit avec les bailleurs, le délégué du Préfet à la Politique de la ville
						 ou les chargés de mission GUP (Gestion Urbaine de Proximité). </span>
				</li>
				<li class="carreV ecartt">
					<span><strong>Des éco médiateurs</strong> pour lutter contre la précarité énergétique. La Régie de Quartiers
						conduit des actions de prévention en partenariat avec EDF, ENEDIS, ENGIE et SUEZ. Notre intervention repose à la fois
						sur des accompagnements individuels et des actions collectives (informations et conseils auprès du public en situation
						de précarité énergétique et/ou impayés, sensibilisation aux éco-gestes, aides financières, chèque énergie...). Depuis
						2016, en partenariat avec ALOGEA, il est proposé aux familles résidant sur le patrimoine "Politique de la ville" du bailleur
						de bénéficier d'un diagnostic énergétique et de conseils pour un bon usage de leur logement (appartements réhabilités BBC ou
						 équivalent). </span>
				</li>
				<img class="rounded mx-auto d-block" src="<?php echo base_url()?>images/atelierCuisine.jpg"/>
				<p class="text-center text-muted"><small>Sensibilisation aux éco-gestes par le biais d'un atelier cuisine - Le Viguier</small></p>
				<li class="carreVert ecartt">
					<span>La conduite <strong>d’actions en faveur du lien social et la participation citoyenne </strong>: l'ambition des 
						Régies de Quartiers est de favoriser la participation des habitants à la vie de leur quartier.
						 La Régie de Quartiers du Carcassonnais cherche systématiquement à co-construire avec les habitants. Par exemple
						 les travaux réalisés dans le cadre des Chantiers Tremplin sont définis à la suite d'une phase de concertation.
						  Les médiateurs participent aux Conseils Citoyens. Aussi, nous jouons un rôle dans la mise en place
						   d'évenements sur les quartiers en lien avec les autres acteurs.</span>
				</li>
				<div class="row">
					<div class="col-md-6">
						<img class="rounded mx-auto d-block" src="<?php echo base_url()?>images/VG-Ozanam.JPG"/>
						<p class="text-center text-muted"><small>Sensibilisation au réemploi par le biais d'un vide grenier - Ozanam </small></p>
					</div>
					<div class="col-md-6">
						<img class="rounded mx-auto d-block" src="<?php echo base_url()?>images/CT-Fleming.jpg"/>
						<p class="text-center text-muted"><small>Concertation en amont d'un Chantier Tremplin - Fleming </small></p>
					</div>
				</div>
			</ul>
		</div>
	</div>
</div>