<script type="text/javascript">
	doActive("contactus")
</script>
<body id="pageContact">
<!--Section: Contact v.2-->
<section class="mb-4 col-md-8 mx-auto">
    <!--Section heading-->
    <h2 class="h1-responsive font-weight-bold text-center my-4">Nous contacter</h2>
    <!--Section description-->
    <?php if(isset($success)){
        if( $success=="ok"){
        	echo "<p class='alert alert-success'>Le mail vient d'être envoyé.</p>";
        } 
        else{
        	 echo "<p class='alert alert-danger'>Le mail n'a pas été envoyé.<p>";
        }
		
    }

    ?>
    <div id="status"></div>
    <div class="row">

        <!--Grid column-->
        <div class="col-md-11 mb-md-0 mb-5">
            <form id="contact-form" name="contact-form" action="mail" method="POST">
            	<input type="hidden" name="secuHidden" value="<?php echo($securite); ?>">
                <!--Grid row-->
                <div class="row">
                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <label for="name" class="" id="LabName"> NOM Prenom</label>
                            <input type="text" id="name" onclick="formActive('LabName')" onfocus="formActive('LabName')" name="name"  class="form-control">
                        </div>
                    </div>
                    <!--Grid column-->
                    
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <input type="text" id="email" name="email"  onclick="formActive('Labmail')" onfocus="formActive('Labmail')" class="form-control">
                            <label for="email" class="" id="Labmail">Mail</label>
                        </div>
                    </div>
                    <!--Grid column-->

                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="md-form mb-0">
                            <label for="subject" class="" id="LabSubject">Sujet du Mail</label>
                            <input type="text" id="subject" name="subject" onclick="formActive('LabSubject')" onfocus="formActive('LabSubject')" class="form-control">     
                        </div>
                    </div>
                </div>
                <!--Grid row-->

                <!--Grid row-->
                <div class="row">

                    <!--Grid column-->
                    <div class="col-md-12">

                        <div class="md-form">
                            <textarea type="text" id="message" name="message" rows="2" onfocus="formActive('Labmsg')" oninput="formActive('Labmsg')" class="form-control md-textarea"></textarea>
                            <label for="message" id="Labmsg">Votre message</label>
                        </div>

                    </div>
                </div>
                <div class="row">
                    <!--Grid column-->
                    <div class="col-md-6">
                        <div class="md-form mb-0">
                            <label for="code" class="" id="LabSecu">Réécrire ce code : <?php echo $securite ?></label>
                            <input type="text" id="secu" onclick="formActive('LabSecu')" onfocus="formActive('LabSecu')" name="secu"  class="form-control">
                        </div>
                </div>
                <!--Grid row-->
                <div class="text-center text-md-left">
                    <a class="btn btn-primary" onclick="validateForm()">Envoyer un Email</a>
            	</div>
            </form>
        </div>
        <!--Grid column-->

        <!--Grid column-->

        <!--Grid column-->

    </div>

</section>
</body>
<script>
    
    function validateForm() {
  var name =  document.getElementById('name').value;
  if (name == "") {
      document.getElementById('status').innerHTML = "Vous devez renseigner votre nom";
      return false;
  }
  var email =  document.getElementById('email').value;
  if (email == "") {
      document.getElementById('status').innerHTML = "Vous devez renseigner votre adresse e-mail";
      return false;
  } else {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      if(!re.test(email)){
          document.getElementById('status').innerHTML = "Le format de votre adresse e-mail est incorrect";
          return false;
      }
  }
  var subject =  document.getElementById('subject').value;
  if (subject == "") {
      document.getElementById('status').innerHTML = "L'objet du mail doit être rempli";
      return false;
  }
  var message =  document.getElementById('message').value;
  if (message == "") {
      document.getElementById('status').innerHTML = "Vous devez renseigné un message";
      return false;
  }
  document.getElementById('status').innerHTML = "Envoi en cour...";
  document.getElementById('contact-form').submit();

  }
  function formActive(id){
      var myElement= document.getElementById(id);
      if(!myElement.classList.contains('active'))
      {
          myElement.classList.add('active');
      }
  }
  
</script>
