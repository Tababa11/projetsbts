<script type="text/javascript">
	doActive("missions")
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="ecart text-center"><strong>L'ensemblier d'insertion</strong> </h2>
			<p class="">Au fil des années, la Régie de Quartiers du Carcassonnais a mis en place <strong>une palette d'outils au service des publics
				en difficulté</strong>, tous ayant pour objectif l'insertion des personnes sans emploi.
				Notre travail repose sur un accompagnement socio-professionnel de proximité et individualisé permettant
				à chacun de construire un projet professionnel,	de tisser du lien social, de s'inscrire dans une dynamique de vie, 
				de résoudre des difficultés...</p>
				<p class="">
					<strong>Nos dispositifs sont les suivants :</strong>
				</p>
			<ul class="maList ">
				<li class="carreV ecartt"><span><strong>Un service de 1er accueil professionnel</strong> permettant d'aider les 
					habitants dans leurs démarches de recherche d'emploi et de formation.</span>
				</li>
				<li class="carreO ecartt"><span><strong>Des Chantiers Tremplin </strong>proposant des contrats courts pour tester une activité
					professionnelle tout en favorisant l'amélioration du cadre de vie des habitants des quartiers prioritaires.</span>
				</li>
				<li class="carreR ecartt"><span><strong>3 Ateliers et Chantiers d’Insertion et 1 Entreprise d’insertion</strong> (IAE) reposant
					sur des contrats de travail plus longs afin d'accompagner les personnes dans la définition et la mise en œuvre de leur
					projet professionnel.</span>
				</li>
				<li class="carreB ecartt"><span><strong>Des postes en contrats aidés</strong> pour travailler sur des projets,
					 des parcours d’insertion professionnelle necessitant des actions de professionnalisation plus longues.</span> 
				</li>
			</ul>
			<p class="">De manière concrète, la Régie de Quartiers propose des contrats de travail aux habitants (selon des critères définis par 
				l'État et le département de l'Aude) ce qui leur permet à la fois d'avoir une activité, un revenu, mais 
				aussi de travailler sur leur montée en compétences et donc leur projet professionnel. Pour cela, chacun des salariés dispose à la fois d'un accompagnement
				en milieu du travail afin de s'approprier les codes du monde du travail (horaires, respect des consignes et de
				la hiérarchie, travail en équipe...) tout en apprenant de nouveaux savoirs techniques. Petit à petit, les salariés vont acquérir
				 des<strong> nouvelles connaissances</strong> en fonction de leur activité support (entretien des espaces intérieurs et exterieurs, ramassage des
				encombrants, peinture, entretien des espaces verts).
				En parallèle, chaque personne est suivie par un conseiller avec lequel elle va <strong>définir son projet professionnel </strong>mais 
				également résoudre ses diverses difficultés (obtention du permis, recherche d'un logement, gestion du budget...)
				</p>
				
			<p class="">
				Nous cherchons systématiquement à positionner les salariés dans <strong>un parcours qualifiant</strong> (formations délivrées en interne
				par les équipes de la Régie ou par des organismes externes de formation). Par exemple, tous les agents d'entretien 
				participent à une formation sur l'hygiène générale, les peintres à une formation sur la pose du papier peint.
			</p>
			<p> Aussi nous entretenons <strong>des liens étroits avec les milieux professionnels </strong>pour mieux connaitre leurs besoins et leurs 
				exigences et ainsi faciliter l'insertion durable de nos publics.
			</p>
			<img class="rounded d-block mx-auto" src="<?php echo base_url();?>images/ensemblier.png"/>
			<p class="text-muted"> 
				<small style="padding-left:14%;"> Formation "Hygiène générale" au CFPM de l'Aude </small> 
				<small style="padding-left:10%;"> Formation "Montage et démontage d'échafaudage"</small>
			</p>
		</div>
	</div>
	<div>
		<img class="rounded" id="imageEnsemblier" src="<?php echo base_url();?>images/Hafsa SADIK.jpg"/>
		<p id="texteEnsemblier" class="text-muted"><small>Entretien des espaces extérieurs</small></p>
	</div>
</div>