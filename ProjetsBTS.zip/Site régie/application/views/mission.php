<script type="text/javascript">
	doActive("missions")
</script>

<div class="container page">
	<div class="row col-md-9 mx-auto">
		<h1>Nos Objectifs Principaux :</h1>
		<ul>
			<li class="maList carreV"><span>Le développement du <strong>lien social,</strong> de la participation active des habitans, de la citoyenneté et des pratiques solidaires.</span></li>
			<li class="maList carreB"><span>L'<strong>insertion</strong> sociale, économique et professionnele des habitans de la Communauté d'Agglomération du Cacassonnais et particulièrement les personnes en difficulté</span></li>
			<li class="maList carreO"><span>L'amélioration du <strong>cadre de vie</strong></span></li>
			<li class="maList carreR"><span>Le <strong>recrutement prioritaire des habitants résidant sur ces quartiers.</strong></span></li>
		</ul>
	</div>
</div>