<script type="text/javascript">
doActive("onr");
</script>
<div class="container page">
	<div class="row">
		<div class="col-md-10 mx-auto text-justify">
			<h2 class="ecart text-center"><strong> Où nous retrouver ?</strong></h2>
			
			<p class=""> La <strong>Régie de Quartiers du Carcassonnais</strong> est présente sur plusieurs quartiers des villes de Carcassonne 
				et de Trèbes :</p>
					<div class="col-md-12 mx-auto">
						<div class="row justify-content-center">
						<div class="col-md-4">
							<ul>
								<li>
									La Conte &amp Joliot Curie
								</li>
								<li>
									Ozanam
								</li>	
								<li>	
									Le Viguier
								</li>	
								<li>	
									Saint-Jacques
								</li>
						</div>
						<div class="col-md-4">
							<ul>
								<li>
									Fleming
								</li>
								<li>
									Grazailles
								</li>
								<li>
									Albignac
								</li>
								<li>
									Trèbes
								</li>
							</ul>
						</div>
					</div>
				</div>
				<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1ywd2Ge8arvxmsEK3O_uT72T-mbEjg_Yp" width="1000" height="600"></iframe>
			</div>
	</div>
</div>
