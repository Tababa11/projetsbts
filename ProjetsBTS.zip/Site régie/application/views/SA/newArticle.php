<body class="allArticles">
	<div class="container">
		<div class="row">
			<div class="bodyWhite col-md-12">
				
			<?php 
			
				if(isset($success)){
			    	if( $success=="yes"){
			    		echo "<p class='alert alert-success'>L'article a été publié.</p>";
			    	}    
			        else{
			        	echo "<p class='alert alert-danger'>L'article n'a pas pu être publié.<p>";
			        }        
			    }


				$this->load->helper('form');
				echo form_open_multipart('Sa/ajouterArticle');
				echo form_fieldset('Nouvelle Actualité');
				
				echo form_label("Titre de l'article :"); echo '<br>';
				$data= array(
				'name' => 'titre',
				'style' => 'width:750px',
				'class' => 'form-control form-control-lg'
				);
				echo form_input($data);
				
				echo'<br><br>';
				echo'<h3>Inserez l\'image qui servira de miniature</h3>';
				echo'<input type="file" name="miniature" />';
				echo'<p>Nous vous conseillons des images au format x par y <a href="https://www.iloveimg.com/fr/redimensionner-image" target="blank">Cliquez ici</a> pour acceder à un redimensionneur d\'images</p>';
				echo'<br>';
				echo form_label("Courte description de l'article");
				echo '<textarea type="text" id="petitedescription" name="description" rows="2" class="form-control md-textarea"></textarea>';
				 
				echo'<br><br>';
				
				echo form_label("Contenu de l'article");
				echo '<textarea type="text" id="description" name="contenu" style="line-height:1.0" rows="10" class="form-control md-textarea"></textarea>';
				echo '<div class="text-center">';
				$data = array(
				 'type' => 'submit',
				 'value' => 'envoyer',
				 'class' => 'btn btn-primary btn-lg'
				 );
				 
				echo form_input($data);
				echo '</div>';
				echo form_fieldset_close();
				echo form_close();
				
				?>
			</div>
		</div>
	</div>
<script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">

bkLib.onDomLoaded(
	function() 
		{	/* utiliser nicEdit complet sur la textarea description */
			new nicEditor().panelInstance('description');
			/* utiliser nicEdit complet sur la textarea description */
			new nicEditor({buttonList : ['fontSize','fontFamily','fontFormat','bold','italic','underline','strikeThrough','subscript','superscript','html']}).panelInstance('petitedescription');
		});

</script>

</body>