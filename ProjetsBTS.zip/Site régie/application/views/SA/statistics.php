<?php 
var_dump($stats);
echo form_open('');
	foreach ($stats as $stat){
		echo form_label($stat['libelle'],$stat['name']);
		$data= array(
		'type' => 'text',
		'value' => $stat['valeur']
		);
		echo form_input($data);
	}
	
	
echo form_close('');





?>