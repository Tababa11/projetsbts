<div class="container">
	<div class="row page">
		<div class="col-md-10 mx-auto text-justify">
			<?php
				echo "<h2 class='ecart text-center'>".$unArticle['0']['titre']."</h2>";
				echo "<section>".$unArticle['0']['contenu'] ."</section>";
				echo "<p class='text-right'>".$unArticle['0']['date']."</p>";
			?>
		</div>
	</div>
</div>