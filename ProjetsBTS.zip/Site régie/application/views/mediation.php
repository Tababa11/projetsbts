<script type="text/javascript">
	doActive("sah")
</script>

<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="ecart text-center "><strong>La Médiation</strong></h2>
			<p class="">Vous êtes concerné par une ou plusieurs de ces problématiques :</p>
			<ul class="maList">
				<li class="carreR ecartt"><span>Vous rencontrez des <strong>problèmes</strong> sur votre quartier (dégradations diverses,
					malpropreté, présence d'encombrants dans les parties communes, non respect des règles de tri, stationnement gênant...). </span></li>
				<li class="carreV ecartt"><span>Vous êtes victime de <strong>conflits</strong> de voisinage. </span></li>
				<li class="carreO ecartt"><span>Vous ne savez pas vers qui vous orienter dans vos <strong>démarches</strong> (demande de logement,
					 dossier santé, orientation vers des professionnels spécialisés, conseils sur l'ouverture des droits, aides administratives diverses...). </span></li>
				<li class="carreVert ecartt"><span>Vous souhaitez des <strong>informations</strong> sur les travaux conduits dans le cadre de la rénovation urbaine. </span></li>
			</ul>
			
			<p>Notre équipe de <strong> médiateurs</strong> est là pour vous accompagner : </p>
			
			<table class="table table-hover">
			  <thead>
			    <tr>
			      <th class="text-center" scope="col text-center mx-auto "><strong>Secteur</strong></th>
			      <th class="text-center" scope="col"><strong>Contacts</strong></th>
			    </tr>
			  </thead>
			  <tbody>
			    <tr>
			      <td class="text-left" scope="row">La Conte et Joliot Curie</td>
			      <td class="text-center" >06.49.60.32.08<br>06.43.06.27.46</td>
			    </tr>
			    <tr>
			      <td class="text-left" scope="row">Ozanam et Albignac</td>
			      <td class="text-center">06.38.42.39.24<br></td>
			    </tr>
			    <tr>
			      <td class="text-left" scope="row">Le Viguier et Saint-Jacques</td>
			      <td class="text-center">06.31.82.91.66<br>06.84.34.41.98</td>
			    </tr>
			    <tr>
			      <td class="text-left" scope="row">Grazailles, Fleming et La Pierre Blanche</td>
			      <td class="text-center">06.38.42.22.05 <br> 06.31.82.90.84</td>
			    </tr>
			  </tbody>
			</table>
			
			<p>Nous pouvons également vous aider pour <strong>toutes questions relatives à la précarité énergétique</strong> (impayés, fonctionnement du chèque énergie, 
				échelonnement de la dette, éco-gestes...) : </p>
				
			<table class="table table-hover">		
				<tbody>
				    <tr>
				      <td class="text-left" > <strong>Eco-Médiateurs</strong> </td>
				      <td class="text-center ecartG">06.73.62.34.95<br>07.84.42.79.37</td>
				    </tr>
			    </tbody>
	
			</table>
		</div>
	</div>
</div>