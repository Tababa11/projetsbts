<script type="text/javascript">
	doActive("accueil")
</script>
<div class="container"> 
    <div class="row carouselMax">
        <div class="col-md-10 mx-auto">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="5000">
              <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="<?php echo base_url();?>images/2.png" alt="First slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100" src="<?php echo base_url();?>images/RegieCite.png" alt="Second slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100" src="<?php echo base_url();?>images/3.png" alt="Third slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100" src="<?php echo base_url();?>images/RegieCavayere.png" alt="Third slide">
                </div>
                <div class="carousel-item">
                  <img class="d-block w-100" src="<?php echo base_url();?>images/1.png" alt="Third slide">
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
              </a>
            </div>
        </div>
    </div>
</div>

<br>

<div class="container filActu">    
	<?php 
		echo '<div class="card-deck">';  	
			foreach($lesArticles as $unArticle){
				
				echo '<div class="card">';
					if($unArticle['validate'])
					{
						$date = explode('-',$unArticle['date']);
						$date = $date['2'].'-'.$date['1'].'-'.$date['0'];	
												
						echo '<img id="imgActu" src="'.base_url().'uploads/'.$unArticle['miniature'].'" class="card-img-top" alt="logo">';
						echo '<div class="card-body">';
							echo '<h5 class="card-title"><a href="'.base_url().'index.php/Accueil/actualites/'.$unArticle['id_article'].'" class="">'.$unArticle['titre'].'</a></h5>';
							echo '<p class="card-text">'.$unArticle['description'].'</p>';
						echo '</div>';
			echo '<div class="card-footer">';
			  echo '<small class="text-muted">'.$date.'</small>';
			  echo '<a id="btnPlus" class="btn btn-dark btn-circle btn-animate" href="'.base_url().'index.php/Accueil/actualites/'.$unArticle['id_article'].'">';
				echo '<span class="blanc">EN SAVOIR PLUS</span>';
			echo '</a>';
			echo '</div>';
					}
				echo '</div>';			
			}
		echo '</div>';    	
	?>
</div>