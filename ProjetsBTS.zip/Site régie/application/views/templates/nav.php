<div class="container-fluid">
	<div class="row bg-secondary">
		<nav class="navbar navbar-expand-lg navbar-expand-sm navbar-dark classnav">
         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>      
			<div class="col collapse navbar-collapse align-items-center justify-content-center" id="navbarSupportedContent">
				<ul class="navbar-nav navigation">
					<li class="nav-item" id="accueil">
						<a class="nav-link" href="<?php echo base_url();?>">Accueil</a>
					</li>
					<li class="nav-item dropdown ecartMenu" id="qsn">
						<a class="nav-link dropdown-toggle " href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Qui sommes-nous ?
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/cnlrq">Le CNLRQ</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/notreHistoire">Notre histoire et nos valeurs</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/notreFonctionnement">Notre fonctionnement</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/partenaires">Nos partenaires financiers</a>	
						</div>
					</li>
					<li class="nav-item dropdown ecartMenu" id="missions">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Nos missions
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/insertionSocialePro">Insertion sociale et professionelle</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/proximite_LS">Proximité - Lien social</a>
						</div>
					</li>
					<li class="nav-item dropdown ecartMenu" id="sah">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Services aux habitants
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/boite_a_linge">Boîte à linge</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/mediation">Médiation</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/aop">Orientation Professionnelle</a>
						</div>
					</li>
					<li class="nav-item ecartMenu" id ="onr">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/ouNousRetrouver"> Où nous retrouver ?</a>
						</li>
					<li class="nav-item ecartMenu" id ="actu">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/lesActus/1"> Actualités </a>
						</li>
					<li class="nav-item ecartMenu" id="join">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/join_us">Rejoignez-nous !</a>
					</li> 
					<li class="nav-item ecartMenu" id="contactus">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/contact">Contact</a>
					</li>
				</ul>
			</div>
                    
		</nav>
		
	</div>
</div>
