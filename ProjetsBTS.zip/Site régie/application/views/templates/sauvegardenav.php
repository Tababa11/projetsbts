<div class="container-fluid">
	<div class="row bg-secondary">
		<nav class="navbar navbar-expand-lg navbar-expand-sm navbar-dark classnav">
                    
			<div class="col collapse navbar-collapse align-items-center justify-content-center" id="navbarNavDropdown">
				<ul class="navbar-nav navigation">
					<li class="nav-item" id="accueil">
						<a class="nav-link" href="<?php echo base_url();?>">Accueil</a>
					</li>
					<li class="nav-item dropdown" id="qsn">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Qui sommes nous ?
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/notreHistoire">Notre histoire et nos valeurs</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/partenaires">Nos partenaires</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/cnlrq">CNLRQ</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/notreFonctionnement">Notre fonctionnement</a>
						</div>
					</li>
					<li class="nav-item dropdown " id="missions">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Nos missions
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/nosMissions">Mission générale</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/insertionSocialePro">Insertion sociale et professionelle</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/proximite_LS">Proximité - Lien social</a>
						</div>
					</li>
					<li class="nav-item dropdown " id="sah">
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Services aux habitants
						</a>
						<div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/boite_a_linge">Boite a linge</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/mediation">Médiation</a>
							<a class="dropdown-item" href="<?php echo base_url();?>index.php/Accueil/aop">Orientation Professionnelle</a>
						</div>
					</li>
					<li class="nav-item " id ="onr">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/ouNousRetrouver"> Où nous retrouver </a>
						</li>
					<li class="nav-item " id ="actu">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/lesActus/1"> Actualités </a>
						</li>
					<li class="nav-item" id="join">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/join_us">Rejoignez nous !</a>
					</li> 
					<li class="nav-item" id="contactus">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Accueil/contact">Nous contacter</a>
					</li>
				</ul>
			</div>
                    
		</nav>
		
	</div>
</div>
