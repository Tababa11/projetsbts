<div class="container-fluid">
	<div class="row bg-secondary">
		<div class="col-md-1 "> </div>
		<nav class="navbar navbar-expand-lg navbar-expand-sm navbar-dark col-md-10 col-sm-10">
                    
			<div class="col collapse navbar-collapse align-items-center justify-content-center" id="navbarNavDropdown">
				<ul class="navbar-nav navigation">
					<li class="nav-item">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Sa/ecrireArticle">Nouvel article</a>
					</li> 
					<li class="nav-item">
						<a class="nav-link" href="<?php echo base_url();?>index.php/Sa/allArticles">Liste des Articles</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo base_url();?>index.php/auth/edit_user/<?php echo $_SESSION['user_id'] ?>">Mon profil</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo base_url();?>index.php/auth/index">Liste des Utilisateurs</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?php echo base_url();?>index.php/auth/logout">Deconnexion</a>
					</li>
				</ul>
			</div>
                    
		</nav>
		<div class="col-md-1"></div>
	</div>
</div>