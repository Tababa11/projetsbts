<div class="footer">
	<footer class="footer" id="footer-fixed">
    <div class="footer-main">
      <div class="container">
        <div class="row">
          <div class="col-sm-7">
            <div class="widget widget-text">
            <div class="row">
              <div class="logo logo-footer"><a href="/"> <img src="<?php echo base_url(); ?>/images/logo.png" alt="logo"/></a> </div>
				<ul id="horaire">
					<h5 class="footerh5"><strong>Horaires :</strong></h5>
					<li>Du Lundi au Jeudi :</li>
					<p class="blanc">de 8h à 12h et de 13h30 à 17h</p>
					<li>Vendredi :</li>
					<p class="blanc">de 8h à 12h</p>
				</ul>
				
				</div>
            </div>
          </div>
          <div class="col-sm-5">
            <div class="widget widget-text widget-links">              
              <ul id="coordonnees">
              	<h5 class="footerh5"><strong>Contactez-nous</strong></h5>
                <li> <i class="fas fa-mobile-alt"></i> 04 68 47 22 71 </li>
                <li> <i class="fas fa-fax"></i> 04 68 25 80 32 </li>
                <li> <i class="fas fa-envelope"></i> secretariat@regiedesquartiers.com </li>
                <li> <a href="https://goo.gl/maps/yyYBbWCvyhK2" target="_blank"><i class="fas fa-map-marker-alt"></i></a> 46 bis, rue Alexandre Guiraud - 11000 Carcassonne </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="footer-copyright">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-xs-12">
          </div>
          <div class="col-md-6 col-xs-12">
            <div class="copy-right text-right">© 2019 Régie de Quartiers du Carcassonnais</div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</div>

		<!-- JQuery -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js%22%3E"</script>
		<!-- Bootstrap tooltips -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js%22%3E"</script>
		<!-- Bootstrap core JavaScript -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js%22%3E"</script>
		<!-- MDB core JavaScript -->
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/js/mdb.min.js%22%3E"</script>
			
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	</body>
</html>