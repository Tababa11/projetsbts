<script type="text/javascript">
	doActive("qsn")
</script>

<div class="container page">
	<div class="row ">
		<div class="col-md-10 mx-auto">
			<h2 class="ecart text-center"><strong>Nos actions sont conduites grâce au soutien de :</strong></h2>
			<img src="<?php echo base_url();?>images/Partenaires.png" alt="Nos partenaires">
		</div>
	</div>
</div>