<script type="text/javascript">
	doActive("qsn")
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="ecart text-center"><strong>Les instances et la participation des habitants</strong></h2>
			<p class="">
				L'organisation de la Régie de Quartiers du Carcassonnais se construit de manière démocratique et repose sur 
				<strong>différentes instances garantes de son projet associatif</strong> : 
			</p>
			<ul class="maList">
				<li class="carreVert ecartt">
					<span><strong>L'Assemblée Générale</strong> représentée par les adhérents, les membres de droit (collectivités, institutions, bailleurs, professionnels), les partenaires de terrain
					(Centres sociaux, Service public de l'emploi dont le Pôle Emploi et la Mission Locale Ouest-Audois, associations dont 
					Couleurs Citoyennes et ABP). Elle se réunit une fois par an, elle propose et vote les grandes orientations de l'assocation
					et élit ses représentants au Conseil d'Administration.</span>
					
				</li>
				<img class="rounded mx-auto d-block" src="<?php echo base_url()?>images/ImageRedim.jpg">
				<p class="text-center text-muted"><small>Assemblée Générale - 2018</small></p>
				<li class="carreO ecartt">
					<span><strong>Le Conseil d'Administration</strong> se réunit 5 fois par an. Il est composé de membres actifs, de membres de droit avec voix consultative. Les représentants du personnel
					sont également conviés à ces réunions. Le Conseil d'Administration a vocation à determiner les choix stratégiques et à voter les budgets par exemple.</span>
				</li>
				<li class="carreB ecartt">
					<span><strong>Le Bureau</strong> se réunit une fois par mois, il est composé uniquement de membres actifs élus parmis les membres du Conseil d'Administration
					 et il est chargé de la mise en œuvre opérationnelle des orientations.</span>
				</li>	
			</ul>
			<p class="">Au quotidien, <strong>la participation des habitants</strong> est un objectif majeur de notre projet associatif.
				Il s'agit de faire avec et surtout de faire pour les habitants.
				Elle se traduit par l'organisation de temps de concertation, d'animations ou encore par la mise en œuvre de projets 
				d'amélioration du cadre de vie sur les quartiers à l'image des Chantiers Tremplin.
			</p>
			<img class="rounded mx-auto d-block" src="<?php echo base_url()?>images/chantierTremplin.PNG"/>
			<p class="text-center text-muted"><small>Travaux réalisés par les habitants dans le cadre du Chantier 
				Tremplin de Grazailles - 2017</small>
			</p>
		</div>
	</div>
</div>