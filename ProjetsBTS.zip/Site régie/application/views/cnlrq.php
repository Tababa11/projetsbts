<script type="text/javascript">
	doActive("qsn")
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="ecart text-center "><strong>Le Comité National de Liaison des Régies de Quartier (CNLRQ)</strong></h2>
			<p class="">
				<strong>Plus de 130 Régies de Quartier et Régies de Territoire</strong> sont implantées sur l’ensemble du territoire national. 
				Elles couvrent 320 quartiers prioritaires où vivent plus de	3 millions d’habitants.	Elles sont représentées par <strong>le 
					CNLRQ qui attribue le label et qui est garant du projet collectif des Régies.</strong>
				Créé en 1988, le Comité National de Liaison des Régies de Quartier est un réseau d'acteurs regroupant les associations labellisées sur l'ensemble du territoire national.
				Son fonctionnement est basé sur le mode de l'échange, de la connaissance mutuelle, du partage des compétences, du transfert des savoir-faire et, plus généralement, de la réciprocité.
				
			</p>
		</div>
	</div>


	<div class="row">
		<div class="col-md-5 mx-auto text-justify">
			<!--<a href="https://www.regiedequartier.org/"><img class="rounded float-right" src="<?php echo base_url(); ?>/images/CNLRQ.png" alt="logo"/></a>-->
			<p class="">
				L’organisation du CNLRQ se construit <strong>de manière démocratique</strong> et repose sur différentes instances chargées d’assumer <strong>une triple mission</strong> :
			</p>
			<ul class="maList ecartt" > 
				<li class="carreO ecartt">
					<span><strong>L’animation</strong> afin de faire fonctionner la vie démocratique au sein du réseau (échanges, capitalisation des expériences, transfert des pratiques entre les Régies…).</span>
				</li>
				<li class="carreV ecartt">
					<span><strong>La représentation du mouvement</strong> auprès des pouvoirs publics et des partenaires nationaux. Le CNLRQ se reconnaît comme partie prenante du mouvement de l’insertion par l’activité économique et est membre fondateur du mouvement de l’économie solidaire.</span> 
				</li>
				<li class="carreVert ecartt">
					<span><strong>Le soutien au développement, quantitatif et qualitatif du réseau national </strong>(appui à la création de nouvelles Régies et aide à celles qui existent).</span>
				</li>
			</ul>
			<p class="">Depuis 2013, la Régie de Quartiers du Carcassonnais est membre du Conseil d'Administration du CNLRQ.</p>
		</div>
		<div class="col-md-5">
			<a href="https://www.regiedequartier.org/wp-content/uploads/2018/07/2018-CarteRegiesQT.pdf" target="blank"><img src="<?php echo base_url(); ?>/images/CarteCNLRQ.PNG" alt="carte des régies"/></a>
		</div>
	</div>
</div>

