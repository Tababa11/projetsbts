<script type="text/javascript">
doActive("join");
</script>
<div class="container page">
	<div class="row">
		<div class="col-10 mx-auto text-justify">
			<h2 class="ecart text-center "><strong>Rejoignez-Nous !</strong></h2>
		<p class="text-center"> 
			Plus de 16 millions de bénévoles œuvrent aujourd’hui dans le paysage associatif français. Se sentir utile et faire quelque chose pour autrui est le moteur de ces bénévoles qui s’impliquent
			 dans des domaines d’activités très divers.
		</p>
		<p class="text-center">Envie de devenir Bénévole ? Cliquez sur "Devenir Bénévole"</p>
		<a class="mx-auto justify-content-center" href="<?php echo base_url();?>index.php/Accueil/contact"><img class="ecart col-md-2 d-block mx-auto" src="<?php echo base_url();?>images/Benevole.PNG" id="btnBenevole" class="rounded mx-auto d-block" alt="Bouton benevole"></a>
		<p class="text-center tRouge">
			<b>Alors pourquoi ne pas partager vos compétences et consacrez une partie de votre temps libre aux activités de l’association </b><strong>Régie de Quartiers du Carcassonnais ?</strong>
		</p>
		</div>
	</div>
</div>