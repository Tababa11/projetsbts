﻿namespace AMSV
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.Fenetres = new System.Windows.Forms.TabControl();
			this.Clients = new System.Windows.Forms.TabPage();
			this.addClient = new System.Windows.Forms.Button();
			this.label18 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.TB_CTel = new System.Windows.Forms.TextBox();
			this.TB_CMail = new System.Windows.Forms.TextBox();
			this.TB_CPrenom = new System.Windows.Forms.TextBox();
			this.TB_CNom = new System.Windows.Forms.TextBox();
			this.ClientAnim = new System.Windows.Forms.Button();
			this.DGClients = new System.Windows.Forms.DataGridView();
			this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Prenom = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Mail = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Tel = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animaux = new System.Windows.Forms.TabPage();
			this.InfosAnim = new System.Windows.Forms.Button();
			this.DGVAnimaux = new System.Windows.Forms.DataGridView();
			this.Animal_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Sexe = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Race = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Animal_Proprietaire = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.InfosClient = new System.Windows.Forms.TabPage();
			this.VoirAnimal = new System.Windows.Forms.Button();
			this.label9 = new System.Windows.Forms.Label();
			this.TBAdd_Anim_Race = new System.Windows.Forms.TextBox();
			this.TBAdd_Anim_Name = new System.Windows.Forms.TextBox();
			this.labelTA = new System.Windows.Forms.Label();
			this.CBTA = new System.Windows.Forms.ComboBox();
			this.label8 = new System.Windows.Forms.Label();
			this.rBFemelle = new System.Windows.Forms.RadioButton();
			this.rBMale = new System.Windows.Forms.RadioButton();
			this.dateNaiss = new System.Windows.Forms.DateTimePicker();
			this.label7 = new System.Windows.Forms.Label();
			this.addAnimal = new System.Windows.Forms.Button();
			this.IC_phraseAnim = new System.Windows.Forms.Label();
			this.IDCACHER = new System.Windows.Forms.Label();
			this.ModifClient = new System.Windows.Forms.Button();
			this.DGCA = new System.Windows.Forms.DataGridView();
			this.ICID_Animal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ICID_TypeAnimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ICID_NomAnimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ICID_SexeAnimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ICID_AgeAnimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ICID_RaceAnimal = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.LIC_ID = new System.Windows.Forms.Label();
			this.LIC_Tel = new System.Windows.Forms.Label();
			this.LIC_Mail = new System.Windows.Forms.Label();
			this.LIC_Prenom = new System.Windows.Forms.Label();
			this.LIC_Nom = new System.Windows.Forms.Label();
			this.TBIC_Tel = new System.Windows.Forms.TextBox();
			this.TBIC_Mail = new System.Windows.Forms.TextBox();
			this.TBIC_Prenom = new System.Windows.Forms.TextBox();
			this.TBIC_Nom = new System.Windows.Forms.TextBox();
			this.InfosAnimal = new System.Windows.Forms.TabPage();
			this.addConsult = new System.Windows.Forms.Button();
			this.ConsultInfo = new System.Windows.Forms.Button();
			this.label10 = new System.Windows.Forms.Label();
			this.DGHC = new System.Windows.Forms.DataGridView();
			this.IDCONSULT = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DateConsultDGHC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Type_Consult_DGHC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.DescDGHC = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.RTBIA_Description = new System.Windows.Forms.RichTextBox();
			this.CBTC = new System.Windows.Forms.ComboBox();
			this.DateConsult = new System.Windows.Forms.DateTimePicker();
			this.LIA_idAnimal = new System.Windows.Forms.Label();
			this.ModifAnimal = new System.Windows.Forms.Button();
			this.TBIA_Race = new System.Windows.Forms.TextBox();
			this.TBIA_TA = new System.Windows.Forms.TextBox();
			this.TBIA_DN = new System.Windows.Forms.TextBox();
			this.TBIA_Sexe = new System.Windows.Forms.TextBox();
			this.TBIA_Nom = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.InfosConsult = new System.Windows.Forms.TabPage();
			this.ID_TC = new System.Windows.Forms.Label();
			this.modif_consult = new System.Windows.Forms.Button();
			this.ID_Consult = new System.Windows.Forms.Label();
			this.CBITC = new System.Windows.Forms.ComboBox();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.RTB_DescIC = new System.Windows.Forms.RichTextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.DateTimeConsult = new System.Windows.Forms.DateTimePicker();
			this.Fenetres.SuspendLayout();
			this.Clients.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGClients)).BeginInit();
			this.Animaux.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGVAnimaux)).BeginInit();
			this.InfosClient.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGCA)).BeginInit();
			this.InfosAnimal.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGHC)).BeginInit();
			this.InfosConsult.SuspendLayout();
			this.SuspendLayout();
			// 
			// Fenetres
			// 
			this.Fenetres.Controls.Add(this.Clients);
			this.Fenetres.Controls.Add(this.Animaux);
			this.Fenetres.Controls.Add(this.InfosClient);
			this.Fenetres.Controls.Add(this.InfosAnimal);
			this.Fenetres.Controls.Add(this.InfosConsult);
			this.Fenetres.Location = new System.Drawing.Point(0, 1);
			this.Fenetres.Name = "Fenetres";
			this.Fenetres.SelectedIndex = 0;
			this.Fenetres.Size = new System.Drawing.Size(1248, 450);
			this.Fenetres.TabIndex = 0;
			// 
			// Clients
			// 
			this.Clients.AllowDrop = true;
			this.Clients.BackColor = System.Drawing.Color.Silver;
			this.Clients.Controls.Add(this.addClient);
			this.Clients.Controls.Add(this.label18);
			this.Clients.Controls.Add(this.label17);
			this.Clients.Controls.Add(this.label16);
			this.Clients.Controls.Add(this.label15);
			this.Clients.Controls.Add(this.TB_CTel);
			this.Clients.Controls.Add(this.TB_CMail);
			this.Clients.Controls.Add(this.TB_CPrenom);
			this.Clients.Controls.Add(this.TB_CNom);
			this.Clients.Controls.Add(this.ClientAnim);
			this.Clients.Controls.Add(this.DGClients);
			this.Clients.Location = new System.Drawing.Point(4, 22);
			this.Clients.Name = "Clients";
			this.Clients.Padding = new System.Windows.Forms.Padding(3);
			this.Clients.Size = new System.Drawing.Size(1240, 424);
			this.Clients.TabIndex = 0;
			this.Clients.Text = "Clients";
			this.Clients.Click += new System.EventHandler(this.Clients_Click);
			// 
			// addClient
			// 
			this.addClient.Location = new System.Drawing.Point(678, 219);
			this.addClient.Name = "addClient";
			this.addClient.Size = new System.Drawing.Size(100, 30);
			this.addClient.TabIndex = 10;
			this.addClient.Text = "Ajouter un Client";
			this.addClient.UseVisualStyleBackColor = true;
			this.addClient.Click += new System.EventHandler(this.addClient_Click);
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(591, 174);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(58, 13);
			this.label18.TabIndex = 9;
			this.label18.Text = "Téléphone";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(591, 128);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(66, 13);
			this.label17.TabIndex = 8;
			this.label17.Text = "Adresse mail";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(591, 86);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(43, 13);
			this.label16.TabIndex = 7;
			this.label16.Text = "Prenom";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(591, 49);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(29, 13);
			this.label15.TabIndex = 6;
			this.label15.Text = "Nom";
			// 
			// TB_CTel
			// 
			this.TB_CTel.Location = new System.Drawing.Point(664, 171);
			this.TB_CTel.Name = "TB_CTel";
			this.TB_CTel.Size = new System.Drawing.Size(147, 20);
			this.TB_CTel.TabIndex = 5;
			// 
			// TB_CMail
			// 
			this.TB_CMail.Location = new System.Drawing.Point(665, 125);
			this.TB_CMail.Name = "TB_CMail";
			this.TB_CMail.Size = new System.Drawing.Size(147, 20);
			this.TB_CMail.TabIndex = 4;
			// 
			// TB_CPrenom
			// 
			this.TB_CPrenom.Location = new System.Drawing.Point(664, 83);
			this.TB_CPrenom.Name = "TB_CPrenom";
			this.TB_CPrenom.Size = new System.Drawing.Size(147, 20);
			this.TB_CPrenom.TabIndex = 3;
			// 
			// TB_CNom
			// 
			this.TB_CNom.Location = new System.Drawing.Point(664, 46);
			this.TB_CNom.Name = "TB_CNom";
			this.TB_CNom.Size = new System.Drawing.Size(147, 20);
			this.TB_CNom.TabIndex = 2;
			// 
			// ClientAnim
			// 
			this.ClientAnim.Location = new System.Drawing.Point(712, 332);
			this.ClientAnim.Name = "ClientAnim";
			this.ClientAnim.Size = new System.Drawing.Size(100, 30);
			this.ClientAnim.TabIndex = 1;
			this.ClientAnim.Text = "Infos Client";
			this.ClientAnim.UseVisualStyleBackColor = true;
			this.ClientAnim.Click += new System.EventHandler(this.ClientAnim_Click);
			// 
			// DGClients
			// 
			this.DGClients.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
			this.DGClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DGClients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Nom,
            this.Prenom,
            this.Mail,
            this.Tel});
			this.DGClients.Location = new System.Drawing.Point(3, 6);
			this.DGClients.Name = "DGClients";
			this.DGClients.Size = new System.Drawing.Size(575, 409);
			this.DGClients.TabIndex = 0;
			this.DGClients.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
			// 
			// Id
			// 
			this.Id.HeaderText = "#";
			this.Id.Name = "Id";
			this.Id.ReadOnly = true;
			this.Id.Width = 30;
			// 
			// Nom
			// 
			this.Nom.HeaderText = "Nom";
			this.Nom.Name = "Nom";
			this.Nom.ReadOnly = true;
			// 
			// Prenom
			// 
			this.Prenom.HeaderText = "Prenom";
			this.Prenom.Name = "Prenom";
			this.Prenom.ReadOnly = true;
			// 
			// Mail
			// 
			this.Mail.HeaderText = "Adresse mail";
			this.Mail.Name = "Mail";
			this.Mail.ReadOnly = true;
			this.Mail.Width = 200;
			// 
			// Tel
			// 
			this.Tel.HeaderText = "Tel";
			this.Tel.Name = "Tel";
			this.Tel.ReadOnly = true;
			// 
			// Animaux
			// 
			this.Animaux.BackColor = System.Drawing.Color.Silver;
			this.Animaux.Controls.Add(this.InfosAnim);
			this.Animaux.Controls.Add(this.DGVAnimaux);
			this.Animaux.Location = new System.Drawing.Point(4, 22);
			this.Animaux.Name = "Animaux";
			this.Animaux.Padding = new System.Windows.Forms.Padding(3);
			this.Animaux.Size = new System.Drawing.Size(1240, 424);
			this.Animaux.TabIndex = 1;
			this.Animaux.Text = "Animaux";
			this.Animaux.Click += new System.EventHandler(this.Animaux_Click);
			// 
			// InfosAnim
			// 
			this.InfosAnim.Location = new System.Drawing.Point(727, 188);
			this.InfosAnim.Name = "InfosAnim";
			this.InfosAnim.Size = new System.Drawing.Size(100, 30);
			this.InfosAnim.TabIndex = 2;
			this.InfosAnim.Text = "Infos Animal";
			this.InfosAnim.UseVisualStyleBackColor = true;
			this.InfosAnim.Click += new System.EventHandler(this.button1_Click);
			// 
			// DGVAnimaux
			// 
			this.DGVAnimaux.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DGVAnimaux.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Animal_ID,
            this.Animal_Nom,
            this.Animal_Sexe,
            this.Animal_Age,
            this.Animal_Type,
            this.Animal_Race,
            this.Animal_Proprietaire});
			this.DGVAnimaux.Location = new System.Drawing.Point(3, 3);
			this.DGVAnimaux.Name = "DGVAnimaux";
			this.DGVAnimaux.Size = new System.Drawing.Size(686, 409);
			this.DGVAnimaux.TabIndex = 0;
			// 
			// Animal_ID
			// 
			this.Animal_ID.HeaderText = "#";
			this.Animal_ID.Name = "Animal_ID";
			this.Animal_ID.ReadOnly = true;
			this.Animal_ID.Width = 20;
			// 
			// Animal_Nom
			// 
			this.Animal_Nom.HeaderText = "Nom";
			this.Animal_Nom.Name = "Animal_Nom";
			this.Animal_Nom.ReadOnly = true;
			// 
			// Animal_Sexe
			// 
			this.Animal_Sexe.HeaderText = "Sexe";
			this.Animal_Sexe.Name = "Animal_Sexe";
			this.Animal_Sexe.ReadOnly = true;
			// 
			// Animal_Age
			// 
			this.Animal_Age.HeaderText = "Age";
			this.Animal_Age.Name = "Animal_Age";
			this.Animal_Age.ReadOnly = true;
			this.Animal_Age.Width = 30;
			// 
			// Animal_Type
			// 
			this.Animal_Type.HeaderText = "Type";
			this.Animal_Type.Name = "Animal_Type";
			this.Animal_Type.ReadOnly = true;
			// 
			// Animal_Race
			// 
			this.Animal_Race.HeaderText = "Race";
			this.Animal_Race.Name = "Animal_Race";
			this.Animal_Race.ReadOnly = true;
			// 
			// Animal_Proprietaire
			// 
			this.Animal_Proprietaire.HeaderText = "# Propriétaire";
			this.Animal_Proprietaire.Name = "Animal_Proprietaire";
			this.Animal_Proprietaire.ReadOnly = true;
			this.Animal_Proprietaire.Width = 80;
			// 
			// InfosClient
			// 
			this.InfosClient.BackColor = System.Drawing.Color.Silver;
			this.InfosClient.Controls.Add(this.VoirAnimal);
			this.InfosClient.Controls.Add(this.label9);
			this.InfosClient.Controls.Add(this.TBAdd_Anim_Race);
			this.InfosClient.Controls.Add(this.TBAdd_Anim_Name);
			this.InfosClient.Controls.Add(this.labelTA);
			this.InfosClient.Controls.Add(this.CBTA);
			this.InfosClient.Controls.Add(this.label8);
			this.InfosClient.Controls.Add(this.rBFemelle);
			this.InfosClient.Controls.Add(this.rBMale);
			this.InfosClient.Controls.Add(this.dateNaiss);
			this.InfosClient.Controls.Add(this.label7);
			this.InfosClient.Controls.Add(this.addAnimal);
			this.InfosClient.Controls.Add(this.IC_phraseAnim);
			this.InfosClient.Controls.Add(this.IDCACHER);
			this.InfosClient.Controls.Add(this.ModifClient);
			this.InfosClient.Controls.Add(this.DGCA);
			this.InfosClient.Controls.Add(this.LIC_ID);
			this.InfosClient.Controls.Add(this.LIC_Tel);
			this.InfosClient.Controls.Add(this.LIC_Mail);
			this.InfosClient.Controls.Add(this.LIC_Prenom);
			this.InfosClient.Controls.Add(this.LIC_Nom);
			this.InfosClient.Controls.Add(this.TBIC_Tel);
			this.InfosClient.Controls.Add(this.TBIC_Mail);
			this.InfosClient.Controls.Add(this.TBIC_Prenom);
			this.InfosClient.Controls.Add(this.TBIC_Nom);
			this.InfosClient.Location = new System.Drawing.Point(4, 22);
			this.InfosClient.Name = "InfosClient";
			this.InfosClient.Size = new System.Drawing.Size(1240, 424);
			this.InfosClient.TabIndex = 3;
			this.InfosClient.Text = "Infos Client";
			this.InfosClient.Click += new System.EventHandler(this.InfosClient_Click);
			// 
			// VoirAnimal
			// 
			this.VoirAnimal.Location = new System.Drawing.Point(527, 37);
			this.VoirAnimal.Name = "VoirAnimal";
			this.VoirAnimal.Size = new System.Drawing.Size(140, 40);
			this.VoirAnimal.TabIndex = 27;
			this.VoirAnimal.Text = "Voir l\'animal";
			this.VoirAnimal.UseVisualStyleBackColor = true;
			this.VoirAnimal.Click += new System.EventHandler(this.VoirAnimal_Click);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(325, 357);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(33, 13);
			this.label9.TabIndex = 26;
			this.label9.Text = "Race";
			// 
			// TBAdd_Anim_Race
			// 
			this.TBAdd_Anim_Race.Location = new System.Drawing.Point(427, 350);
			this.TBAdd_Anim_Race.Name = "TBAdd_Anim_Race";
			this.TBAdd_Anim_Race.Size = new System.Drawing.Size(162, 20);
			this.TBAdd_Anim_Race.TabIndex = 25;
			// 
			// TBAdd_Anim_Name
			// 
			this.TBAdd_Anim_Name.Location = new System.Drawing.Point(427, 232);
			this.TBAdd_Anim_Name.Name = "TBAdd_Anim_Name";
			this.TBAdd_Anim_Name.Size = new System.Drawing.Size(162, 20);
			this.TBAdd_Anim_Name.TabIndex = 24;
			// 
			// labelTA
			// 
			this.labelTA.AutoSize = true;
			this.labelTA.Location = new System.Drawing.Point(325, 326);
			this.labelTA.Name = "labelTA";
			this.labelTA.Size = new System.Drawing.Size(72, 13);
			this.labelTA.TabIndex = 23;
			this.labelTA.Text = "Type d\'animal";
			// 
			// CBTA
			// 
			this.CBTA.FormattingEnabled = true;
			this.CBTA.Location = new System.Drawing.Point(427, 323);
			this.CBTA.Name = "CBTA";
			this.CBTA.Size = new System.Drawing.Size(162, 21);
			this.CBTA.TabIndex = 22;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(325, 299);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(96, 13);
			this.label8.TabIndex = 20;
			this.label8.Text = "Date de naissance";
			// 
			// rBFemelle
			// 
			this.rBFemelle.AutoSize = true;
			this.rBFemelle.Location = new System.Drawing.Point(518, 261);
			this.rBFemelle.Name = "rBFemelle";
			this.rBFemelle.Size = new System.Drawing.Size(61, 17);
			this.rBFemelle.TabIndex = 19;
			this.rBFemelle.TabStop = true;
			this.rBFemelle.Text = "Femelle";
			this.rBFemelle.UseVisualStyleBackColor = true;
			// 
			// rBMale
			// 
			this.rBMale.AutoSize = true;
			this.rBMale.Location = new System.Drawing.Point(427, 261);
			this.rBMale.Name = "rBMale";
			this.rBMale.Size = new System.Drawing.Size(48, 17);
			this.rBMale.TabIndex = 18;
			this.rBMale.TabStop = true;
			this.rBMale.Text = "Male";
			this.rBMale.UseVisualStyleBackColor = true;
			// 
			// dateNaiss
			// 
			this.dateNaiss.Location = new System.Drawing.Point(427, 293);
			this.dateNaiss.Name = "dateNaiss";
			this.dateNaiss.Size = new System.Drawing.Size(162, 20);
			this.dateNaiss.TabIndex = 17;
			this.dateNaiss.Value = new System.DateTime(2019, 5, 19, 0, 0, 0, 0);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(381, 239);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(29, 13);
			this.label7.TabIndex = 16;
			this.label7.Text = "Nom";
			// 
			// addAnimal
			// 
			this.addAnimal.Location = new System.Drawing.Point(439, 384);
			this.addAnimal.Name = "addAnimal";
			this.addAnimal.Size = new System.Drawing.Size(140, 40);
			this.addAnimal.TabIndex = 15;
			this.addAnimal.Text = "Ajouter Animal";
			this.addAnimal.UseVisualStyleBackColor = true;
			this.addAnimal.Click += new System.EventHandler(this.addAnimal_Click);
			// 
			// IC_phraseAnim
			// 
			this.IC_phraseAnim.AutoSize = true;
			this.IC_phraseAnim.Location = new System.Drawing.Point(132, 12);
			this.IC_phraseAnim.Name = "IC_phraseAnim";
			this.IC_phraseAnim.Size = new System.Drawing.Size(0, 13);
			this.IC_phraseAnim.TabIndex = 13;
			// 
			// IDCACHER
			// 
			this.IDCACHER.AutoSize = true;
			this.IDCACHER.Location = new System.Drawing.Point(767, 107);
			this.IDCACHER.Name = "IDCACHER";
			this.IDCACHER.Size = new System.Drawing.Size(0, 13);
			this.IDCACHER.TabIndex = 12;
			this.IDCACHER.Visible = false;
			// 
			// ModifClient
			// 
			this.ModifClient.Location = new System.Drawing.Point(81, 384);
			this.ModifClient.Name = "ModifClient";
			this.ModifClient.Size = new System.Drawing.Size(140, 40);
			this.ModifClient.TabIndex = 11;
			this.ModifClient.Text = "Modifier le client";
			this.ModifClient.UseVisualStyleBackColor = true;
			this.ModifClient.Click += new System.EventHandler(this.ModifClient_Click);
			// 
			// DGCA
			// 
			this.DGCA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DGCA.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ICID_Animal,
            this.ICID_TypeAnimal,
            this.ICID_NomAnimal,
            this.ICID_SexeAnimal,
            this.ICID_AgeAnimal,
            this.ICID_RaceAnimal});
			this.DGCA.Location = new System.Drawing.Point(23, 37);
			this.DGCA.Name = "DGCA";
			this.DGCA.Size = new System.Drawing.Size(476, 167);
			this.DGCA.TabIndex = 10;
			this.DGCA.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
			// 
			// ICID_Animal
			// 
			this.ICID_Animal.HeaderText = "#";
			this.ICID_Animal.Name = "ICID_Animal";
			this.ICID_Animal.ReadOnly = true;
			this.ICID_Animal.Width = 20;
			// 
			// ICID_TypeAnimal
			// 
			this.ICID_TypeAnimal.HeaderText = "Type";
			this.ICID_TypeAnimal.Name = "ICID_TypeAnimal";
			this.ICID_TypeAnimal.ReadOnly = true;
			// 
			// ICID_NomAnimal
			// 
			this.ICID_NomAnimal.HeaderText = "Nom";
			this.ICID_NomAnimal.Name = "ICID_NomAnimal";
			this.ICID_NomAnimal.ReadOnly = true;
			// 
			// ICID_SexeAnimal
			// 
			this.ICID_SexeAnimal.HeaderText = "Sexe";
			this.ICID_SexeAnimal.Name = "ICID_SexeAnimal";
			this.ICID_SexeAnimal.ReadOnly = true;
			this.ICID_SexeAnimal.Width = 70;
			// 
			// ICID_AgeAnimal
			// 
			this.ICID_AgeAnimal.HeaderText = "Age";
			this.ICID_AgeAnimal.Name = "ICID_AgeAnimal";
			this.ICID_AgeAnimal.ReadOnly = true;
			this.ICID_AgeAnimal.Width = 30;
			// 
			// ICID_RaceAnimal
			// 
			this.ICID_RaceAnimal.HeaderText = "Race";
			this.ICID_RaceAnimal.Name = "ICID_RaceAnimal";
			this.ICID_RaceAnimal.ReadOnly = true;
			// 
			// LIC_ID
			// 
			this.LIC_ID.AutoSize = true;
			this.LIC_ID.Location = new System.Drawing.Point(102, 230);
			this.LIC_ID.Name = "LIC_ID";
			this.LIC_ID.Size = new System.Drawing.Size(0, 13);
			this.LIC_ID.TabIndex = 9;
			// 
			// LIC_Tel
			// 
			this.LIC_Tel.AutoSize = true;
			this.LIC_Tel.Location = new System.Drawing.Point(20, 361);
			this.LIC_Tel.Name = "LIC_Tel";
			this.LIC_Tel.Size = new System.Drawing.Size(115, 13);
			this.LIC_Tel.TabIndex = 8;
			this.LIC_Tel.Text = "Numéro de téléphone :";
			// 
			// LIC_Mail
			// 
			this.LIC_Mail.AutoSize = true;
			this.LIC_Mail.Location = new System.Drawing.Point(20, 329);
			this.LIC_Mail.Name = "LIC_Mail";
			this.LIC_Mail.Size = new System.Drawing.Size(82, 13);
			this.LIC_Mail.TabIndex = 7;
			this.LIC_Mail.Text = "Adresse E-mail :";
			// 
			// LIC_Prenom
			// 
			this.LIC_Prenom.AutoSize = true;
			this.LIC_Prenom.Location = new System.Drawing.Point(20, 295);
			this.LIC_Prenom.Name = "LIC_Prenom";
			this.LIC_Prenom.Size = new System.Drawing.Size(49, 13);
			this.LIC_Prenom.TabIndex = 6;
			this.LIC_Prenom.Text = "Prenom :";
			// 
			// LIC_Nom
			// 
			this.LIC_Nom.AutoSize = true;
			this.LIC_Nom.Location = new System.Drawing.Point(20, 261);
			this.LIC_Nom.Name = "LIC_Nom";
			this.LIC_Nom.Size = new System.Drawing.Size(35, 13);
			this.LIC_Nom.TabIndex = 5;
			this.LIC_Nom.Text = "Nom :";
			// 
			// TBIC_Tel
			// 
			this.TBIC_Tel.Location = new System.Drawing.Point(135, 358);
			this.TBIC_Tel.Name = "TBIC_Tel";
			this.TBIC_Tel.Size = new System.Drawing.Size(162, 20);
			this.TBIC_Tel.TabIndex = 3;
			// 
			// TBIC_Mail
			// 
			this.TBIC_Mail.Location = new System.Drawing.Point(135, 326);
			this.TBIC_Mail.Name = "TBIC_Mail";
			this.TBIC_Mail.Size = new System.Drawing.Size(162, 20);
			this.TBIC_Mail.TabIndex = 2;
			// 
			// TBIC_Prenom
			// 
			this.TBIC_Prenom.Enabled = false;
			this.TBIC_Prenom.Location = new System.Drawing.Point(135, 292);
			this.TBIC_Prenom.Name = "TBIC_Prenom";
			this.TBIC_Prenom.Size = new System.Drawing.Size(162, 20);
			this.TBIC_Prenom.TabIndex = 1;
			// 
			// TBIC_Nom
			// 
			this.TBIC_Nom.Enabled = false;
			this.TBIC_Nom.Location = new System.Drawing.Point(135, 258);
			this.TBIC_Nom.Name = "TBIC_Nom";
			this.TBIC_Nom.ReadOnly = true;
			this.TBIC_Nom.Size = new System.Drawing.Size(162, 20);
			this.TBIC_Nom.TabIndex = 0;
			// 
			// InfosAnimal
			// 
			this.InfosAnimal.BackColor = System.Drawing.Color.Silver;
			this.InfosAnimal.Controls.Add(this.addConsult);
			this.InfosAnimal.Controls.Add(this.ConsultInfo);
			this.InfosAnimal.Controls.Add(this.label10);
			this.InfosAnimal.Controls.Add(this.DGHC);
			this.InfosAnimal.Controls.Add(this.RTBIA_Description);
			this.InfosAnimal.Controls.Add(this.CBTC);
			this.InfosAnimal.Controls.Add(this.DateConsult);
			this.InfosAnimal.Controls.Add(this.LIA_idAnimal);
			this.InfosAnimal.Controls.Add(this.ModifAnimal);
			this.InfosAnimal.Controls.Add(this.TBIA_Race);
			this.InfosAnimal.Controls.Add(this.TBIA_TA);
			this.InfosAnimal.Controls.Add(this.TBIA_DN);
			this.InfosAnimal.Controls.Add(this.TBIA_Sexe);
			this.InfosAnimal.Controls.Add(this.TBIA_Nom);
			this.InfosAnimal.Controls.Add(this.label6);
			this.InfosAnimal.Controls.Add(this.label5);
			this.InfosAnimal.Controls.Add(this.label4);
			this.InfosAnimal.Controls.Add(this.label3);
			this.InfosAnimal.Controls.Add(this.label2);
			this.InfosAnimal.Controls.Add(this.label1);
			this.InfosAnimal.Location = new System.Drawing.Point(4, 22);
			this.InfosAnimal.Name = "InfosAnimal";
			this.InfosAnimal.Padding = new System.Windows.Forms.Padding(3);
			this.InfosAnimal.Size = new System.Drawing.Size(1240, 424);
			this.InfosAnimal.TabIndex = 4;
			this.InfosAnimal.Text = "Infos Animal";
			this.InfosAnimal.Click += new System.EventHandler(this.InfosAnimal_Click);
			// 
			// addConsult
			// 
			this.addConsult.Location = new System.Drawing.Point(655, 361);
			this.addConsult.Name = "addConsult";
			this.addConsult.Size = new System.Drawing.Size(140, 40);
			this.addConsult.TabIndex = 21;
			this.addConsult.Text = "Programmer Consultation";
			this.addConsult.UseVisualStyleBackColor = true;
			this.addConsult.Click += new System.EventHandler(this.addConsult_Click);
			// 
			// ConsultInfo
			// 
			this.ConsultInfo.Location = new System.Drawing.Point(411, 202);
			this.ConsultInfo.Name = "ConsultInfo";
			this.ConsultInfo.Size = new System.Drawing.Size(140, 40);
			this.ConsultInfo.TabIndex = 20;
			this.ConsultInfo.Text = "Info sur la Consultation";
			this.ConsultInfo.UseVisualStyleBackColor = true;
			this.ConsultInfo.Click += new System.EventHandler(this.ConsultInfo_Click);
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(555, 3);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(139, 13);
			this.label10.TabIndex = 19;
			this.label10.Text = "Historique des consultations";
			// 
			// DGHC
			// 
			this.DGHC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DGHC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDCONSULT,
            this.DateConsultDGHC,
            this.Type_Consult_DGHC,
            this.DescDGHC});
			this.DGHC.Location = new System.Drawing.Point(368, 23);
			this.DGHC.Name = "DGHC";
			this.DGHC.Size = new System.Drawing.Size(470, 173);
			this.DGHC.TabIndex = 18;
			this.DGHC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_2);
			// 
			// IDCONSULT
			// 
			this.IDCONSULT.HeaderText = "#";
			this.IDCONSULT.Name = "IDCONSULT";
			this.IDCONSULT.ReadOnly = true;
			this.IDCONSULT.Width = 20;
			// 
			// DateConsultDGHC
			// 
			this.DateConsultDGHC.HeaderText = "Date consultation";
			this.DateConsultDGHC.Name = "DateConsultDGHC";
			this.DateConsultDGHC.ReadOnly = true;
			// 
			// Type_Consult_DGHC
			// 
			this.Type_Consult_DGHC.HeaderText = "Type de consultation";
			this.Type_Consult_DGHC.Name = "Type_Consult_DGHC";
			this.Type_Consult_DGHC.ReadOnly = true;
			// 
			// DescDGHC
			// 
			this.DescDGHC.HeaderText = "Description ";
			this.DescDGHC.Name = "DescDGHC";
			this.DescDGHC.ReadOnly = true;
			this.DescDGHC.Width = 200;
			// 
			// RTBIA_Description
			// 
			this.RTBIA_Description.Location = new System.Drawing.Point(625, 262);
			this.RTBIA_Description.Name = "RTBIA_Description";
			this.RTBIA_Description.Size = new System.Drawing.Size(202, 93);
			this.RTBIA_Description.TabIndex = 17;
			this.RTBIA_Description.Text = "";
			// 
			// CBTC
			// 
			this.CBTC.FormattingEnabled = true;
			this.CBTC.Location = new System.Drawing.Point(627, 235);
			this.CBTC.Name = "CBTC";
			this.CBTC.Size = new System.Drawing.Size(200, 21);
			this.CBTC.TabIndex = 16;
			this.CBTC.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// DateConsult
			// 
			this.DateConsult.Location = new System.Drawing.Point(627, 209);
			this.DateConsult.Name = "DateConsult";
			this.DateConsult.Size = new System.Drawing.Size(200, 20);
			this.DateConsult.TabIndex = 15;
			this.DateConsult.Value = new System.DateTime(2019, 5, 19, 0, 0, 0, 0);
			// 
			// LIA_idAnimal
			// 
			this.LIA_idAnimal.AutoSize = true;
			this.LIA_idAnimal.Location = new System.Drawing.Point(296, 23);
			this.LIA_idAnimal.Name = "LIA_idAnimal";
			this.LIA_idAnimal.Size = new System.Drawing.Size(0, 13);
			this.LIA_idAnimal.TabIndex = 14;
			// 
			// ModifAnimal
			// 
			this.ModifAnimal.Location = new System.Drawing.Point(189, 315);
			this.ModifAnimal.Name = "ModifAnimal";
			this.ModifAnimal.Size = new System.Drawing.Size(140, 40);
			this.ModifAnimal.TabIndex = 13;
			this.ModifAnimal.Text = "Modifier l\'animal";
			this.ModifAnimal.UseVisualStyleBackColor = true;
			this.ModifAnimal.Click += new System.EventHandler(this.ModifAnimal_Click);
			// 
			// TBIA_Race
			// 
			this.TBIA_Race.Enabled = false;
			this.TBIA_Race.Location = new System.Drawing.Point(189, 252);
			this.TBIA_Race.Name = "TBIA_Race";
			this.TBIA_Race.Size = new System.Drawing.Size(162, 20);
			this.TBIA_Race.TabIndex = 10;
			// 
			// TBIA_TA
			// 
			this.TBIA_TA.Enabled = false;
			this.TBIA_TA.Location = new System.Drawing.Point(189, 206);
			this.TBIA_TA.Name = "TBIA_TA";
			this.TBIA_TA.Size = new System.Drawing.Size(162, 20);
			this.TBIA_TA.TabIndex = 9;
			// 
			// TBIA_DN
			// 
			this.TBIA_DN.Enabled = false;
			this.TBIA_DN.Location = new System.Drawing.Point(189, 159);
			this.TBIA_DN.Name = "TBIA_DN";
			this.TBIA_DN.Size = new System.Drawing.Size(162, 20);
			this.TBIA_DN.TabIndex = 8;
			// 
			// TBIA_Sexe
			// 
			this.TBIA_Sexe.Enabled = false;
			this.TBIA_Sexe.Location = new System.Drawing.Point(189, 112);
			this.TBIA_Sexe.Name = "TBIA_Sexe";
			this.TBIA_Sexe.Size = new System.Drawing.Size(162, 20);
			this.TBIA_Sexe.TabIndex = 7;
			// 
			// TBIA_Nom
			// 
			this.TBIA_Nom.Location = new System.Drawing.Point(189, 65);
			this.TBIA_Nom.Name = "TBIA_Nom";
			this.TBIA_Nom.Size = new System.Drawing.Size(162, 20);
			this.TBIA_Nom.TabIndex = 6;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(68, 255);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(33, 13);
			this.label6.TabIndex = 5;
			this.label6.Text = "Race";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(68, 209);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(65, 13);
			this.label5.TabIndex = 4;
			this.label5.Text = "Type Animal";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(68, 162);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(98, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "Date de Naissance";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(68, 115);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(31, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Sexe";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(206, 23);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(84, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "Id de l\'animal : #";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(68, 68);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(29, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Nom";
			// 
			// InfosConsult
			// 
			this.InfosConsult.BackColor = System.Drawing.Color.Silver;
			this.InfosConsult.Controls.Add(this.ID_TC);
			this.InfosConsult.Controls.Add(this.modif_consult);
			this.InfosConsult.Controls.Add(this.ID_Consult);
			this.InfosConsult.Controls.Add(this.CBITC);
			this.InfosConsult.Controls.Add(this.label14);
			this.InfosConsult.Controls.Add(this.label13);
			this.InfosConsult.Controls.Add(this.label12);
			this.InfosConsult.Controls.Add(this.RTB_DescIC);
			this.InfosConsult.Controls.Add(this.label11);
			this.InfosConsult.Controls.Add(this.DateTimeConsult);
			this.InfosConsult.Location = new System.Drawing.Point(4, 22);
			this.InfosConsult.Name = "InfosConsult";
			this.InfosConsult.Size = new System.Drawing.Size(1240, 424);
			this.InfosConsult.TabIndex = 5;
			this.InfosConsult.Text = "Infos Consultation";
			this.InfosConsult.Click += new System.EventHandler(this.InfosConsult_Click);
			// 
			// ID_TC
			// 
			this.ID_TC.AutoSize = true;
			this.ID_TC.Location = new System.Drawing.Point(531, 45);
			this.ID_TC.Name = "ID_TC";
			this.ID_TC.Size = new System.Drawing.Size(0, 13);
			this.ID_TC.TabIndex = 23;
			this.ID_TC.Visible = false;
			// 
			// modif_consult
			// 
			this.modif_consult.Location = new System.Drawing.Point(263, 281);
			this.modif_consult.Name = "modif_consult";
			this.modif_consult.Size = new System.Drawing.Size(140, 40);
			this.modif_consult.TabIndex = 22;
			this.modif_consult.Text = "Modifier Consultation";
			this.modif_consult.UseVisualStyleBackColor = true;
			this.modif_consult.Click += new System.EventHandler(this.modif_consult_Click);
			// 
			// ID_Consult
			// 
			this.ID_Consult.AutoSize = true;
			this.ID_Consult.Location = new System.Drawing.Point(351, 23);
			this.ID_Consult.Name = "ID_Consult";
			this.ID_Consult.Size = new System.Drawing.Size(0, 13);
			this.ID_Consult.TabIndex = 8;
			// 
			// CBITC
			// 
			this.CBITC.FormattingEnabled = true;
			this.CBITC.Location = new System.Drawing.Point(249, 73);
			this.CBITC.Name = "CBITC";
			this.CBITC.Size = new System.Drawing.Size(169, 21);
			this.CBITC.TabIndex = 7;
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(109, 73);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(107, 13);
			this.label14.TabIndex = 6;
			this.label14.Text = "Type de Consultation";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(109, 121);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(117, 13);
			this.label13.TabIndex = 5;
			this.label13.Text = "Date de la Consultation";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(109, 196);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(120, 13);
			this.label12.TabIndex = 4;
			this.label12.Text = "Description consultation";
			// 
			// RTB_DescIC
			// 
			this.RTB_DescIC.Location = new System.Drawing.Point(249, 159);
			this.RTB_DescIC.Name = "RTB_DescIC";
			this.RTB_DescIC.Size = new System.Drawing.Size(169, 103);
			this.RTB_DescIC.TabIndex = 3;
			this.RTB_DescIC.Text = "";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(225, 23);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(120, 13);
			this.label11.TabIndex = 2;
			this.label11.Text = "ID de la consultation : #";
			// 
			// DateTimeConsult
			// 
			this.DateTimeConsult.Location = new System.Drawing.Point(249, 114);
			this.DateTimeConsult.Name = "DateTimeConsult";
			this.DateTimeConsult.Size = new System.Drawing.Size(169, 20);
			this.DateTimeConsult.TabIndex = 1;
			this.DateTimeConsult.Value = new System.DateTime(2019, 5, 20, 0, 0, 0, 0);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(843, 450);
			this.Controls.Add(this.Fenetres);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Form1";
			this.Text = "AMSV";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Fenetres.ResumeLayout(false);
			this.Clients.ResumeLayout(false);
			this.Clients.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGClients)).EndInit();
			this.Animaux.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.DGVAnimaux)).EndInit();
			this.InfosClient.ResumeLayout(false);
			this.InfosClient.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGCA)).EndInit();
			this.InfosAnimal.ResumeLayout(false);
			this.InfosAnimal.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.DGHC)).EndInit();
			this.InfosConsult.ResumeLayout(false);
			this.InfosConsult.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Fenetres;
        private System.Windows.Forms.TabPage Clients;
        private System.Windows.Forms.TabPage Animaux;
		private System.Windows.Forms.DataGridView DGClients;
		private System.Windows.Forms.Button ClientAnim;
		private System.Windows.Forms.TabPage InfosClient;
		private System.Windows.Forms.Label LIC_ID;
		private System.Windows.Forms.Label LIC_Tel;
		private System.Windows.Forms.Label LIC_Mail;
		private System.Windows.Forms.Label LIC_Prenom;
		private System.Windows.Forms.Label LIC_Nom;
		private System.Windows.Forms.TextBox TBIC_Tel;
		private System.Windows.Forms.TextBox TBIC_Mail;
		private System.Windows.Forms.TextBox TBIC_Prenom;
		private System.Windows.Forms.TextBox TBIC_Nom;
		private System.Windows.Forms.DataGridView DGCA;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_Animal;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_TypeAnimal;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_NomAnimal;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_SexeAnimal;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_AgeAnimal;
		private System.Windows.Forms.DataGridViewTextBoxColumn ICID_RaceAnimal;
		private System.Windows.Forms.DataGridViewTextBoxColumn Id;
		private System.Windows.Forms.DataGridViewTextBoxColumn Nom;
		private System.Windows.Forms.DataGridViewTextBoxColumn Prenom;
		private System.Windows.Forms.DataGridViewTextBoxColumn Mail;
		private System.Windows.Forms.DataGridViewTextBoxColumn Tel;
		private System.Windows.Forms.Button ModifClient;
		private System.Windows.Forms.Label IDCACHER;
		private System.Windows.Forms.Label IC_phraseAnim;
		private System.Windows.Forms.DataGridView DGVAnimaux;
		private System.Windows.Forms.Button InfosAnim;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_ID;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Nom;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Sexe;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Age;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Type;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Race;
		private System.Windows.Forms.DataGridViewTextBoxColumn Animal_Proprietaire;
		private System.Windows.Forms.TabPage InfosAnimal;
		private System.Windows.Forms.TextBox TBIA_Race;
		private System.Windows.Forms.TextBox TBIA_TA;
		private System.Windows.Forms.TextBox TBIA_DN;
		private System.Windows.Forms.TextBox TBIA_Sexe;
		private System.Windows.Forms.TextBox TBIA_Nom;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button addAnimal;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox TBAdd_Anim_Race;
		private System.Windows.Forms.TextBox TBAdd_Anim_Name;
		private System.Windows.Forms.Label labelTA;
		private System.Windows.Forms.ComboBox CBTA;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.RadioButton rBFemelle;
		private System.Windows.Forms.RadioButton rBMale;
		private System.Windows.Forms.DateTimePicker dateNaiss;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Button ModifAnimal;
		private System.Windows.Forms.Label LIA_idAnimal;
		private System.Windows.Forms.Button VoirAnimal;
		private System.Windows.Forms.Button ConsultInfo;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.DataGridView DGHC;
		private System.Windows.Forms.RichTextBox RTBIA_Description;
		private System.Windows.Forms.ComboBox CBTC;
		private System.Windows.Forms.DateTimePicker DateConsult;
		private System.Windows.Forms.Button addConsult;
		private System.Windows.Forms.DataGridViewTextBoxColumn IDCONSULT;
		private System.Windows.Forms.DataGridViewTextBoxColumn DateConsultDGHC;
		private System.Windows.Forms.DataGridViewTextBoxColumn Type_Consult_DGHC;
		private System.Windows.Forms.DataGridViewTextBoxColumn DescDGHC;
		private System.Windows.Forms.TabPage InfosConsult;
		private System.Windows.Forms.ComboBox CBITC;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.RichTextBox RTB_DescIC;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.DateTimePicker DateTimeConsult;
		private System.Windows.Forms.Label ID_Consult;
		private System.Windows.Forms.Button modif_consult;
		private System.Windows.Forms.Label ID_TC;
		private System.Windows.Forms.Button addClient;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox TB_CTel;
		private System.Windows.Forms.TextBox TB_CMail;
		private System.Windows.Forms.TextBox TB_CPrenom;
		private System.Windows.Forms.TextBox TB_CNom;
	}
}

