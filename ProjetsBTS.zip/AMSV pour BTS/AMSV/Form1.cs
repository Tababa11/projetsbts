﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace AMSV
{
    public partial class Form1 : Form
    {
		
        public Form1()
        {
            InitializeComponent();
            
        }
		private void Form1_Load(object sender, EventArgs e)
        {
			MySqlConnection coBD = this.connexionBD();
			fillAnimaux();
			fillClients();
			fillCBTA();
			fillCBTC();
			InfosClient.Enabled = false ;
			InfosAnimal.Enabled = false ;
			InfosConsult.Enabled = false;
		}
		//Retourne configuration d'accès au serveur de base de données
		private MySqlConnection connexionBD()
		{
			MySqlConnection coBD = new MySqlConnection("database=lvs; server=localhost; user id=root; pwd=");
			coBD.Open();
			return coBD;
		}
		private void fillCBTA()
		{
			CBTA.Items.Clear();
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select * from type_animaux ";
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				CBTA.Items.Add(reader["Libelle"]);
			}

		}
		private void fillCBITC()
		{
			CBITC.Items.Clear();
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select * from type_consultations ";
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				CBITC.Items.Add(reader["libelle"]);
			}
		}
		private void fillCBTC()
		{
			CBTC.Items.Clear();
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select * from type_consultations ";
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				CBTC.Items.Add(reader["libelle"]);
			}
		}

		// Remplissage de la DataGridView 
		// Remplissage de la liste et sert aussi d'actualisation de la DGV
		private void fillAnimaux()
		{
			DGVAnimaux.Rows.Clear();
			MySqlConnection coBD = this.connexionBD();
			string id, nom, sexe, age, type, race, idproprietaire;
			DGClients.Rows.Clear();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "SELECT * FROM view_client_anim_infos";
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				id = reader["ID"].ToString();
				nom = reader["Nom"].ToString();
				sexe = reader["Sexe"].ToString();
				age = reader["Age"].ToString();
				type = reader["Type_Animal"].ToString();
				race = reader["Race"].ToString();
				idproprietaire = reader["idProprietaire"].ToString();
				DGVAnimaux.Rows.Add(id, nom, sexe, age, type, race, idproprietaire);
			}
			reader.Close();
			coBD.Close();

		}
		// Rempli la DataGridView DGClient 
		// Rempli la liste des Client et sert d'actualisation de la DGV
		private void fillClients()
		{
			MySqlConnection coBD = this.connexionBD();
			string id, nom, prenom, mail, tel;
			DGClients.Rows.Clear();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select * from Clients";
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				id = reader["ID"].ToString();
				nom = reader["Nom"].ToString();
				prenom = reader["Prenom"].ToString();
				mail = reader["Mail"].ToString();
				tel = reader["Tel"].ToString() ;
				DGClients.Rows.Add(id, nom, prenom, mail, tel);
			}
			reader.Close();
			coBD.Close();
		}
		private void fillConsult(int idConsult)
		{
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select consultations.ID as ID, Date, Description,IdTC, libelle  from consultations,type_consultations where IdTC=type_consultations.ID and consultations.id =@idConsult ";
			cmd.Parameters.AddWithValue("@idConsult", idConsult);
			MySqlDataReader reader = cmd.ExecuteReader();
			reader.Read();
			DateTimeConsult.Value = Convert.ToDateTime(reader["Date"].ToString());
			RTB_DescIC.Text = reader["Description"].ToString();
			ID_Consult.Text = reader["ID"].ToString();
			fillCBITC();
			CBITC.SelectedIndex = CBITC.FindString(reader["libelle"].ToString());
		}

		//Rempli la page Infos Animal selon le client selectionné sur DGVAnimal
		private void fillAnimal(int idAnimal)
		{
			LIA_idAnimal.Text = ""+idAnimal;
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select Nom, Sexe, DateNaissance, libelle, Race, idProprietaire  from Animaux,type_animaux where animaux.Id = @idanimal and type_animaux.ID=idTA";
			cmd.Parameters.AddWithValue("@idanimal", idAnimal);
			MySqlDataReader reader = cmd.ExecuteReader();
			reader.Read();
			TBIA_Nom.Text = reader["Nom"].ToString();
			TBIA_Sexe.Text = reader["Sexe"].ToString();
			TBIA_DN.Text = reader["DateNaissance"].ToString();
			TBIA_TA.Text = reader["libelle"].ToString();
			TBIA_Race.Text = reader["Race"].ToString();
			fillDGHC();
		}

		private void fillDGHC()
		{
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			DGHC.Rows.Clear();
			string idAnimal = LIA_idAnimal.Text;
			string Description, date , idConsultation,Type_Consult;
			cmd.CommandText = "select consultations.Id,Date,libelle as Type_Consult,Description from consultations,type_consultations where IdAnimal = @idAnimal and IdTC = type_consultations.ID";
			cmd.Parameters.AddWithValue("@idAnimal", idAnimal);
			MySqlDataReader reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				idConsultation = reader["ID"].ToString();
				date = reader["Date"].ToString();
				Description = reader["Description"].ToString();
				Type_Consult = reader["Type_Consult"].ToString();
				DGHC.Rows.Add(idConsultation, date, Type_Consult, Description);

			}
		}

		// Rempli la page Infos Client selon le client selectionné sur DGClient
		private void fillClient(int idClient)
		{
			//Debut remplissage info client
			string nom, prenom, mail, tel;
			IC_phraseAnim.Text = "Animaux du Client #"+idClient;
			LIC_ID.Text = "ID DU CLIENT : #" + idClient;
			IDCACHER.Text = idClient.ToString();
			MySqlConnection coBD = this.connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "select * from clients where ID = @idClient";
			cmd.Parameters.AddWithValue("@idClient", idClient);
			MySqlDataReader reader = cmd.ExecuteReader();
			reader.Read();
			nom = reader["Nom"].ToString();
			prenom = reader["Prenom"].ToString();
			mail = reader["Mail"].ToString();
			tel = reader["Tel"].ToString();
			TBIC_Mail.Text = mail;
			TBIC_Nom.Text = nom;
			TBIC_Prenom.Text = prenom;
			TBIC_Tel.Text = tel;
			reader.Close();
			//Fin remplissage info Client
			//Debut remplissage animaux possedé par le client
			DGCA.Rows.Clear();
			string idAnimal, nomAnimal, sexeAnimal, ageAnimal, typeAnimal, raceAnimal;
			cmd.CommandText = "select * from view_client_anim_infos where idProprietaire = @idClient";
			reader = cmd.ExecuteReader();
			while (reader.Read())
			{
				idAnimal = reader["ID"].ToString()  ;
				nomAnimal = reader["Nom"].ToString() ;
				sexeAnimal = reader["Sexe"].ToString() ;
				ageAnimal = reader["Age"].ToString() ;
				typeAnimal = reader["Type_Animal"].ToString() ;
				raceAnimal = reader["Race"].ToString() ;
				DGCA.Rows.Add(idAnimal, typeAnimal, nomAnimal, sexeAnimal, ageAnimal, raceAnimal);

			}
			reader.Close();


		}
		private void BddClients_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void Clients_Click(object sender, EventArgs e)
		{

		}

		private void ClientAnim_Click(object sender, EventArgs e)
		{
			if( DGClients.SelectedRows.Count > 0 && DGClients.SelectedRows.Count < 2)
			{
				InfosClient.Enabled = true;
				Fenetres.SelectedIndex=2;
				DataGridViewRow SelectedRow = DGClients.SelectedRows[0];
				string id =SelectedRow.Cells[0].Value.ToString();
				fillClient(int.Parse(id));
			}
			else
			{
				MessageBox.Show("Veuillez selectionner une ligne");
			}
		}

		private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void InfosClient_Click(object sender, EventArgs e)
		{

		}

		private void ModifClient_Click(object sender, EventArgs e)
		{
		
			string mail =TBIC_Mail.Text, tel = TBIC_Tel.Text, ID = IDCACHER.Text;
			MySqlConnection coBD = connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "update clients set Mail = @mail, Tel = @tel where ID = @ID";
			cmd.Parameters.AddWithValue("@mail", mail);
			cmd.Parameters.AddWithValue("@ID", ID);
			cmd.Parameters.AddWithValue("@tel", tel);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Modification effectuée");
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
			fillClients();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (DGVAnimaux.SelectedRows.Count > 0 && DGVAnimaux.SelectedRows.Count < 2)
			{
				InfosAnimal.Enabled = true;
				Fenetres.SelectedIndex = 3;
				DataGridViewRow SelectedRow = DGVAnimaux.SelectedRows[0];
				string id = SelectedRow.Cells[0].Value.ToString();
				fillAnimal(int.Parse(id));
			}
			else
			{
				MessageBox.Show("Veuillez Selectionner un animal");
			}
		}

		private void Animaux_Click(object sender, EventArgs e)
		{

		}

		private void button3_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{

		}
		private void addAnimal_Click(object sender, EventArgs e)
		{
			string ID = IDCACHER.Text;
			string nom = TBAdd_Anim_Name.Text;
			string Type_Animal = CBTA.SelectedItem.ToString();
			string Race = TBAdd_Anim_Race.Text;
			string Sexe="Non défini";
			string idTA="-1";

			if (rBFemelle.Checked)
			{ Sexe = "Femelle"; }
			else if (rBMale.Checked)
			{ Sexe = "Male"; }
			DateTime dateNaissance = dateNaiss.Value ;
			MySqlConnection coBD = connexionBD();
			MySqlCommand cmdid = coBD.CreateCommand();
			cmdid.CommandText="select id from type_animaux where libelle=@Type_Animal";
			cmdid.Parameters.AddWithValue("@Type_Animal", Type_Animal);
			MySqlDataReader reader = cmdid.ExecuteReader();
			reader.Read();
			idTA = reader["id"].ToString();
			reader.Close();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "insert into Animaux(Nom,Sexe,DateNaissance,IdTA,Race,idProprietaire) values (@Nom,@Sexe,@DateNaissance,@IdTA,@Race,@ID)";
			cmd.Parameters.AddWithValue("@ID", ID);
			cmd.Parameters.AddWithValue("@Nom", nom);
			cmd.Parameters.AddWithValue("@Sexe", Sexe);
			cmd.Parameters.AddWithValue("@DateNaissance", dateNaissance);
			cmd.Parameters.AddWithValue("@IdTA", idTA);
			cmd.Parameters.AddWithValue("@Race", Race);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Animal ajouté.");
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
			fillClient(int.Parse(ID));
		}

		private void showOwner_Click(object sender, EventArgs e)
		{
			InfosClient.Enabled = true;
			Fenetres.SelectedIndex = 2;
			//string id = ;
			//fillClient(int.Parse(id));
		}

		private void ModifAnimal_Click(object sender, EventArgs e)
		{
			string nom = TBIA_Nom.Text;
			string id = LIA_idAnimal.Text;
			MySqlConnection coBD = connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "update animaux set Nom = @nom  where ID = @ID";
			cmd.Parameters.AddWithValue("@nom", nom);    
			cmd.Parameters.AddWithValue("@ID", id);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Modification effectuée");
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
			fillAnimaux();
		}

		private void VoirAnimal_Click(object sender, EventArgs e)
		{
			if (DGCA.SelectedRows.Count > 0 && DGCA.SelectedRows.Count<2 )
			{
				InfosAnimal.Enabled = true;
				Fenetres.SelectedIndex = 3;
				DataGridViewRow SelectedRow = DGCA.SelectedRows[0];
				string id = SelectedRow.Cells[0].Value.ToString();
				fillAnimal(int.Parse(id));
			}
			else
			{
				MessageBox.Show("Veuillez Selectionner un animal");
			}
		}

		private void addConsult_Click(object sender, EventArgs e)
		{
			string Type_Consult = CBTC.SelectedItem.ToString();
			string Description = RTBIA_Description.Text;
			string idTC = "-1";
			string idAnimal = LIA_idAnimal.Text;
			DateTime DateConsultation = DateConsult.Value;

			MySqlConnection coBD = connexionBD();
			MySqlCommand cmdid = coBD.CreateCommand();
			cmdid.CommandText = "select id from type_consultations where libelle=@Type_Consult";
			cmdid.Parameters.AddWithValue("@Type_Consult", Type_Consult);
			MySqlDataReader reader = cmdid.ExecuteReader();
			reader.Read();
			idTC = reader["id"].ToString();
			reader.Close();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "insert into consultations(IdAnimal,Date,IdTC,Description) values (@IdAnimal,@DateConsultation,@idTC,@Description)";
			cmd.Parameters.AddWithValue("@IdAnimal", idAnimal);
			cmd.Parameters.AddWithValue("@DateConsultation", DateConsultation);
			cmd.Parameters.AddWithValue("@idTC", idTC);
			cmd.Parameters.AddWithValue("@Description", Description);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Consultation enregistrée");
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
			fillDGHC();
		}

		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void InfosAnimal_Click(object sender, EventArgs e)
		{

		}

		private void dataGridView1_CellContentClick_2(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void ConsultInfo_Click(object sender, EventArgs e)
		{
			if (DGHC.SelectedRows.Count > 0 && DGHC.SelectedRows.Count < 2)
			{
				InfosConsult.Enabled = true;
				Fenetres.SelectedIndex = 4;
				DataGridViewRow SelectedRow = DGHC.SelectedRows[0];
				string id = SelectedRow.Cells[0].Value.ToString();
				fillConsult(int.Parse(id));
			}
			else
			{
				MessageBox.Show("Veuillez Selectionner un animal");
			}
		}

		private void modif_consult_Click(object sender, EventArgs e)
		{
			string Type_Consult = CBITC.SelectedItem.ToString();
			string Description = RTB_DescIC.Text;
			string idAnimal = LIA_idAnimal.Text;
			string idTC = "-1" ;
			DateTime DateConsultation = DateTimeConsult.Value;

			MySqlConnection coBD = connexionBD();
			MySqlCommand cmdid = coBD.CreateCommand();
			cmdid.CommandText = "select id from type_consultations where libelle=@Type_Consult";
			cmdid.Parameters.AddWithValue("@Type_Consult", Type_Consult);
			MySqlDataReader reader = cmdid.ExecuteReader();
			reader.Read();
			idTC = reader["id"].ToString();
			reader.Close();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "update consultations set Description = @Description , Date = @DateConsultation, IdTC = @idTC where Id = @ID_Consult";
			cmd.Parameters.AddWithValue("@Description", Description);
			cmd.Parameters.AddWithValue("@DateConsultation", DateConsultation);
			cmd.Parameters.AddWithValue("@idTC", idTC);
			cmd.Parameters.AddWithValue("@ID_Consult", ID_Consult.Text);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Consultation modifiée");
				fillDGHC();
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
			fillDGHC();
		}

		private void InfosConsult_Click(object sender, EventArgs e)
		{

		}

		private void addClient_Click(object sender, EventArgs e)
		{
			string Nom, Prenom, Mail, Tel;
			Nom = TB_CNom.Text;
			Prenom = TB_CPrenom.Text;
			Mail = TB_CMail.Text;
			Tel = TB_CTel.Text;
			MySqlConnection coBD = connexionBD();
			MySqlCommand cmd = coBD.CreateCommand();
			cmd.CommandText = "insert into Clients(Nom,Prenom,Mail,Tel) values (@Nom,@Prenom,@Mail,@Tel)";
			cmd.Parameters.AddWithValue("@Nom", Nom);
			cmd.Parameters.AddWithValue("@Prenom", Prenom);
			cmd.Parameters.AddWithValue("@Mail", Mail);
			cmd.Parameters.AddWithValue("@Tel", Tel);
			if (cmd.ExecuteNonQuery() == 1)
			{
				MessageBox.Show("Client enregistré.");
				fillClients();
			}
			else
			{
				MessageBox.Show("un problème a été rencontré");
			}
		}
	}
}
