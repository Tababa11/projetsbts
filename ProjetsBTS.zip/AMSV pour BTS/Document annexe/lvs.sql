-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 23 mai 2019 à 18:45
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `lvs`
--

-- --------------------------------------------------------

--
-- Structure de la table `animaux`
--

DROP TABLE IF EXISTS `animaux`;
CREATE TABLE IF NOT EXISTS `animaux` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(200) NOT NULL,
  `Sexe` varchar(7) NOT NULL,
  `DateNaissance` date DEFAULT NULL,
  `IdTA` int(11) NOT NULL,
  `Race` varchar(200) NOT NULL,
  `idProprietaire` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `idProprietaire` (`idProprietaire`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Déclencheurs `animaux`
--
DROP TRIGGER IF EXISTS `TBI_Animaux`;
DELIMITER $$
CREATE TRIGGER `TBI_Animaux` BEFORE INSERT ON `animaux` FOR EACH ROW BEGIN

	IF new.Sexe = 'Male' THEN
        update statistiques set statistiques.NbMale = statistiques.NbMale+1, statistiques.NbAnimaux= statistiques.NbAnimaux+1;
    END IF;
    IF new.Sexe = 'Femelle' THEN
        update statistiques set statistiques.NbFemelle = statistiques.NbFemelle+1, statistiques.NbAnimaux= statistiques.NbAnimaux+1;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

DROP TABLE IF EXISTS `clients`;
CREATE TABLE IF NOT EXISTS `clients` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(30) NOT NULL,
  `Prenom` varchar(30) NOT NULL,
  `Mail` varchar(100) NOT NULL,
  `Tel` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déclencheurs `clients`
--
DROP TRIGGER IF EXISTS `TBI_Clients`;
DELIMITER $$
CREATE TRIGGER `TBI_Clients` BEFORE INSERT ON `clients` FOR EACH ROW BEGIN
UPDATE statistiques set statistiques.NbClient=statistiques.NbClient+1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `consultations`
--

DROP TABLE IF EXISTS `consultations`;
CREATE TABLE IF NOT EXISTS `consultations` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `IdAnimal` int(11) NOT NULL,
  `Date` date NOT NULL,
  `IdTC` int(11) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `statistiques`
--

DROP TABLE IF EXISTS `statistiques`;
CREATE TABLE IF NOT EXISTS `statistiques` (
  `idinutile` int(11) NOT NULL AUTO_INCREMENT,
  `NbClient` int(11) NOT NULL,
  `NbAnimaux` int(11) NOT NULL,
  `NbMale` int(11) NOT NULL,
  `NbFemelle` int(11) NOT NULL,
  PRIMARY KEY (`idinutile`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `statistiques`
--

INSERT INTO `statistiques` (`idinutile`, `NbClient`, `NbAnimaux`, `NbMale`, `NbFemelle`) VALUES
(1, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `type_animaux`
--

DROP TABLE IF EXISTS `type_animaux`;
CREATE TABLE IF NOT EXISTS `type_animaux` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Libelle` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `type_animaux`
--

INSERT INTO `type_animaux` (`ID`, `Libelle`) VALUES
(1, 'Chien'),
(2, 'Chat');

-- --------------------------------------------------------

--
-- Structure de la table `type_consultations`
--

DROP TABLE IF EXISTS `type_consultations`;
CREATE TABLE IF NOT EXISTS `type_consultations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `type_consultations`
--

INSERT INTO `type_consultations` (`id`, `libelle`) VALUES
(1, 'Consultation de routine'),
(2, 'Consultation pré-opératoire'),
(3, 'Coupe des griffes'),
(4, 'Consultation chien mordeur'),
(5, 'Visite en vue d’un voyage à l’étranger');

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `view_client_anim_infos`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `view_client_anim_infos`;
CREATE TABLE IF NOT EXISTS `view_client_anim_infos` (
`ID` int(11)
,`Nom` varchar(200)
,`Sexe` varchar(7)
,`Age` int(5)
,`Type_Animal` varchar(50)
,`Race` varchar(200)
,`idProprietaire` int(11)
);

-- --------------------------------------------------------

--
-- Structure de la vue `view_client_anim_infos`
--
DROP TABLE IF EXISTS `view_client_anim_infos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_client_anim_infos`  AS  select `animaux`.`Id` AS `ID`,`animaux`.`Nom` AS `Nom`,`animaux`.`Sexe` AS `Sexe`,(year(now()) - year(`animaux`.`DateNaissance`)) AS `Age`,`type_animaux`.`Libelle` AS `Type_Animal`,`animaux`.`Race` AS `Race`,`animaux`.`idProprietaire` AS `idProprietaire` from ((`animaux` join `type_animaux`) join `clients`) where ((`animaux`.`idProprietaire` = `clients`.`ID`) and (`animaux`.`IdTA` = `type_animaux`.`ID`)) ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
